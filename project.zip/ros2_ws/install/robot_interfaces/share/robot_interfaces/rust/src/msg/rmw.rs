#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__BnoReading() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__BnoReading__init(msg: *mut BnoReading) -> bool;
    fn robot_interfaces__msg__BnoReading__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<BnoReading>, size: usize) -> bool;
    fn robot_interfaces__msg__BnoReading__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<BnoReading>);
    fn robot_interfaces__msg__BnoReading__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<BnoReading>, out_seq: *mut rosidl_runtime_rs::Sequence<BnoReading>) -> bool;
}

// Corresponds to robot_interfaces__msg__BnoReading
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BnoReading {

    // This member is not documented.
    #[allow(missing_docs)]
    pub current_angle: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pitch: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub roll: f32,

}



impl Default for BnoReading {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__BnoReading__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__BnoReading__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for BnoReading {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__BnoReading__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__BnoReading__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__BnoReading__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for BnoReading {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for BnoReading where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/BnoReading";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__BnoReading() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Encoder() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__Encoder__init(msg: *mut Encoder) -> bool;
    fn robot_interfaces__msg__Encoder__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Encoder>, size: usize) -> bool;
    fn robot_interfaces__msg__Encoder__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Encoder>);
    fn robot_interfaces__msg__Encoder__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Encoder>, out_seq: *mut rosidl_runtime_rs::Sequence<Encoder>) -> bool;
}

// Corresponds to robot_interfaces__msg__Encoder
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Encoder {

    // This member is not documented.
    #[allow(missing_docs)]
    pub xticks: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub yticks: i32,

}



impl Default for Encoder {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__Encoder__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__Encoder__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Encoder {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Encoder__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Encoder__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Encoder__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Encoder {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Encoder where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/Encoder";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Encoder() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Lidar() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__Lidar__init(msg: *mut Lidar) -> bool;
    fn robot_interfaces__msg__Lidar__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Lidar>, size: usize) -> bool;
    fn robot_interfaces__msg__Lidar__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Lidar>);
    fn robot_interfaces__msg__Lidar__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Lidar>, out_seq: *mut rosidl_runtime_rs::Sequence<Lidar>) -> bool;
}

// Corresponds to robot_interfaces__msg__Lidar
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Lidar {

    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_front: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_back: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_left: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_right: f32,

}



impl Default for Lidar {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__Lidar__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__Lidar__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Lidar {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Lidar__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Lidar__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Lidar__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Lidar {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Lidar where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/Lidar";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Lidar() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__LimitSwitch() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__LimitSwitch__init(msg: *mut LimitSwitch) -> bool;
    fn robot_interfaces__msg__LimitSwitch__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<LimitSwitch>, size: usize) -> bool;
    fn robot_interfaces__msg__LimitSwitch__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<LimitSwitch>);
    fn robot_interfaces__msg__LimitSwitch__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<LimitSwitch>, out_seq: *mut rosidl_runtime_rs::Sequence<LimitSwitch>) -> bool;
}

// Corresponds to robot_interfaces__msg__LimitSwitch
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LimitSwitch {

    // This member is not documented.
    #[allow(missing_docs)]
    pub ls1: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ls2: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ls3: i32,

}



impl Default for LimitSwitch {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__LimitSwitch__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__LimitSwitch__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for LimitSwitch {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__LimitSwitch__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__LimitSwitch__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__LimitSwitch__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for LimitSwitch {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for LimitSwitch where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/LimitSwitch";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__LimitSwitch() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Velocity() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__Velocity__init(msg: *mut Velocity) -> bool;
    fn robot_interfaces__msg__Velocity__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Velocity>, size: usize) -> bool;
    fn robot_interfaces__msg__Velocity__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Velocity>);
    fn robot_interfaces__msg__Velocity__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Velocity>, out_seq: *mut rosidl_runtime_rs::Sequence<Velocity>) -> bool;
}

// Corresponds to robot_interfaces__msg__Velocity
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Velocity {

    // This member is not documented.
    #[allow(missing_docs)]
    pub vx: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub vy: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub vw: f32,

}



impl Default for Velocity {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__Velocity__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__Velocity__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Velocity {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Velocity__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Velocity__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Velocity__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Velocity {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Velocity where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/Velocity";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Velocity() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__BallScrew() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__BallScrew__init(msg: *mut BallScrew) -> bool;
    fn robot_interfaces__msg__BallScrew__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<BallScrew>, size: usize) -> bool;
    fn robot_interfaces__msg__BallScrew__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<BallScrew>);
    fn robot_interfaces__msg__BallScrew__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<BallScrew>, out_seq: *mut rosidl_runtime_rs::Sequence<BallScrew>) -> bool;
}

// Corresponds to robot_interfaces__msg__BallScrew
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// Ball Screw motor commands (ROS -> MCU)
/// -1 = lower, 0 is stop, 1 = raise

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BallScrew {

    // This member is not documented.
    #[allow(missing_docs)]
    pub front_cmd: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub back_cmd: i8,

}



impl Default for BallScrew {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__BallScrew__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__BallScrew__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for BallScrew {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__BallScrew__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__BallScrew__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__BallScrew__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for BallScrew {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for BallScrew where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/BallScrew";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__BallScrew() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__ClimbMotors() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__ClimbMotors__init(msg: *mut ClimbMotors) -> bool;
    fn robot_interfaces__msg__ClimbMotors__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ClimbMotors>, size: usize) -> bool;
    fn robot_interfaces__msg__ClimbMotors__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ClimbMotors>);
    fn robot_interfaces__msg__ClimbMotors__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ClimbMotors>, out_seq: *mut rosidl_runtime_rs::Sequence<ClimbMotors>) -> bool;
}

// Corresponds to robot_interfaces__msg__ClimbMotors
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// Climb motor velocities (ROS -> MCU)
/// For the 2 climb wheel motors
/// To go front and back on your secondary drive 

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ClimbMotors {

    // This member is not documented.
    #[allow(missing_docs)]
    pub front_velocity: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub back_velocity: f32,

}



impl Default for ClimbMotors {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__ClimbMotors__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__ClimbMotors__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ClimbMotors {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ClimbMotors__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ClimbMotors__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ClimbMotors__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ClimbMotors {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ClimbMotors where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/ClimbMotors";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__ClimbMotors() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Odom() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__Odom__init(msg: *mut Odom) -> bool;
    fn robot_interfaces__msg__Odom__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Odom>, size: usize) -> bool;
    fn robot_interfaces__msg__Odom__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Odom>);
    fn robot_interfaces__msg__Odom__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Odom>, out_seq: *mut rosidl_runtime_rs::Sequence<Odom>) -> bool;
}

// Corresponds to robot_interfaces__msg__Odom
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Odom {

    // This member is not documented.
    #[allow(missing_docs)]
    pub odom_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub odom_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub current_angle: f32,

}



impl Default for Odom {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__Odom__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__Odom__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Odom {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Odom__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Odom__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Odom__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Odom {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Odom where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/Odom";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Odom() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Irsensors() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__Irsensors__init(msg: *mut Irsensors) -> bool;
    fn robot_interfaces__msg__Irsensors__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Irsensors>, size: usize) -> bool;
    fn robot_interfaces__msg__Irsensors__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Irsensors>);
    fn robot_interfaces__msg__Irsensors__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Irsensors>, out_seq: *mut rosidl_runtime_rs::Sequence<Irsensors>) -> bool;
}

// Corresponds to robot_interfaces__msg__Irsensors
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Irsensors {

    // This member is not documented.
    #[allow(missing_docs)]
    pub ir1: i16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ir2: i16,

}



impl Default for Irsensors {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__Irsensors__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__Irsensors__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Irsensors {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Irsensors__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Irsensors__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Irsensors__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Irsensors {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Irsensors where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/Irsensors";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Irsensors() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__ServoSpearhead() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__ServoSpearhead__init(msg: *mut ServoSpearhead) -> bool;
    fn robot_interfaces__msg__ServoSpearhead__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ServoSpearhead>, size: usize) -> bool;
    fn robot_interfaces__msg__ServoSpearhead__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ServoSpearhead>);
    fn robot_interfaces__msg__ServoSpearhead__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ServoSpearhead>, out_seq: *mut rosidl_runtime_rs::Sequence<ServoSpearhead>) -> bool;
}

// Corresponds to robot_interfaces__msg__ServoSpearhead
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// Servo command for spearhead pickup mechanism
/// servo_finger: angle for finger/gripper servo (0-180)
/// servo_wrist: angle for wrist/rotation servo (0-180)

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ServoSpearhead {

    // This member is not documented.
    #[allow(missing_docs)]
    pub servo_finger: i16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub servo_wrist: i16,

}



impl Default for ServoSpearhead {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__ServoSpearhead__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__ServoSpearhead__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ServoSpearhead {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ServoSpearhead__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ServoSpearhead__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ServoSpearhead__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ServoSpearhead {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ServoSpearhead where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/ServoSpearhead";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__ServoSpearhead() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__IR() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__IR__init(msg: *mut IR) -> bool;
    fn robot_interfaces__msg__IR__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<IR>, size: usize) -> bool;
    fn robot_interfaces__msg__IR__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<IR>);
    fn robot_interfaces__msg__IR__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<IR>, out_seq: *mut rosidl_runtime_rs::Sequence<IR>) -> bool;
}

// Corresponds to robot_interfaces__msg__IR
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IR {

    // This member is not documented.
    #[allow(missing_docs)]
    pub irbot: i16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub irwall: i16,

}



impl Default for IR {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__IR__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__IR__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for IR {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__IR__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__IR__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__IR__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for IR {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for IR where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/IR";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__IR() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__ClimbJhonsonEnc() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__ClimbJhonsonEnc__init(msg: *mut ClimbJhonsonEnc) -> bool;
    fn robot_interfaces__msg__ClimbJhonsonEnc__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ClimbJhonsonEnc>, size: usize) -> bool;
    fn robot_interfaces__msg__ClimbJhonsonEnc__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ClimbJhonsonEnc>);
    fn robot_interfaces__msg__ClimbJhonsonEnc__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ClimbJhonsonEnc>, out_seq: *mut rosidl_runtime_rs::Sequence<ClimbJhonsonEnc>) -> bool;
}

// Corresponds to robot_interfaces__msg__ClimbJhonsonEnc
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ClimbJhonsonEnc {

    // This member is not documented.
    #[allow(missing_docs)]
    pub front_ticks: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub back_ticks: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub front_at_lower_limit: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub back_at_lower_limit: bool,

}



impl Default for ClimbJhonsonEnc {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__ClimbJhonsonEnc__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__ClimbJhonsonEnc__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ClimbJhonsonEnc {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ClimbJhonsonEnc__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ClimbJhonsonEnc__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ClimbJhonsonEnc__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ClimbJhonsonEnc {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ClimbJhonsonEnc where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/ClimbJhonsonEnc";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__ClimbJhonsonEnc() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__GridData() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__GridData__init(msg: *mut GridData) -> bool;
    fn robot_interfaces__msg__GridData__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GridData>, size: usize) -> bool;
    fn robot_interfaces__msg__GridData__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GridData>);
    fn robot_interfaces__msg__GridData__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GridData>, out_seq: *mut rosidl_runtime_rs::Sequence<GridData>) -> bool;
}

// Corresponds to robot_interfaces__msg__GridData
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GridData {

    // This member is not documented.
    #[allow(missing_docs)]
    pub layout: [i32; 12],

}



impl Default for GridData {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__GridData__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__GridData__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GridData {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__GridData__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__GridData__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__GridData__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GridData {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GridData where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/GridData";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__GridData() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Grippers() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__Grippers__init(msg: *mut Grippers) -> bool;
    fn robot_interfaces__msg__Grippers__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Grippers>, size: usize) -> bool;
    fn robot_interfaces__msg__Grippers__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Grippers>);
    fn robot_interfaces__msg__Grippers__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Grippers>, out_seq: *mut rosidl_runtime_rs::Sequence<Grippers>) -> bool;
}

// Corresponds to robot_interfaces__msg__Grippers
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Grippers {

    // This member is not documented.
    #[allow(missing_docs)]
    pub gripper1: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub gripper2: bool,

}



impl Default for Grippers {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__Grippers__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__Grippers__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Grippers {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Grippers__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Grippers__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Grippers__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Grippers {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Grippers where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/Grippers";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Grippers() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__DepthIR() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__DepthIR__init(msg: *mut DepthIR) -> bool;
    fn robot_interfaces__msg__DepthIR__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<DepthIR>, size: usize) -> bool;
    fn robot_interfaces__msg__DepthIR__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<DepthIR>);
    fn robot_interfaces__msg__DepthIR__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<DepthIR>, out_seq: *mut rosidl_runtime_rs::Sequence<DepthIR>) -> bool;
}

// Corresponds to robot_interfaces__msg__DepthIR
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DepthIR {
    /// for now assuming its aligned with global 90
    pub frontir: i16,

}



impl Default for DepthIR {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__DepthIR__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__DepthIR__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for DepthIR {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__DepthIR__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__DepthIR__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__DepthIR__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for DepthIR {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for DepthIR where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/DepthIR";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__DepthIR() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__ClimbIR() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__ClimbIR__init(msg: *mut ClimbIR) -> bool;
    fn robot_interfaces__msg__ClimbIR__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ClimbIR>, size: usize) -> bool;
    fn robot_interfaces__msg__ClimbIR__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ClimbIR>);
    fn robot_interfaces__msg__ClimbIR__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ClimbIR>, out_seq: *mut rosidl_runtime_rs::Sequence<ClimbIR>) -> bool;
}

// Corresponds to robot_interfaces__msg__ClimbIR
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ClimbIR {

    // This member is not documented.
    #[allow(missing_docs)]
    pub front_wheel: i16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub back_wheel: i16,

}



impl Default for ClimbIR {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__ClimbIR__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__ClimbIR__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ClimbIR {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ClimbIR__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ClimbIR__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ClimbIR__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ClimbIR {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ClimbIR where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/ClimbIR";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__ClimbIR() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__KfsServiceLimitSwitch() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__KfsServiceLimitSwitch__init(msg: *mut KfsServiceLimitSwitch) -> bool;
    fn robot_interfaces__msg__KfsServiceLimitSwitch__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<KfsServiceLimitSwitch>, size: usize) -> bool;
    fn robot_interfaces__msg__KfsServiceLimitSwitch__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<KfsServiceLimitSwitch>);
    fn robot_interfaces__msg__KfsServiceLimitSwitch__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<KfsServiceLimitSwitch>, out_seq: *mut rosidl_runtime_rs::Sequence<KfsServiceLimitSwitch>) -> bool;
}

// Corresponds to robot_interfaces__msg__KfsServiceLimitSwitch
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct KfsServiceLimitSwitch {

    // This member is not documented.
    #[allow(missing_docs)]
    pub limit_switch_front: i16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub limit_switch_backs: i16,

}



impl Default for KfsServiceLimitSwitch {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__KfsServiceLimitSwitch__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__KfsServiceLimitSwitch__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for KfsServiceLimitSwitch {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__KfsServiceLimitSwitch__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__KfsServiceLimitSwitch__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__KfsServiceLimitSwitch__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for KfsServiceLimitSwitch {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for KfsServiceLimitSwitch where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/KfsServiceLimitSwitch";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__KfsServiceLimitSwitch() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__GantryVel() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__GantryVel__init(msg: *mut GantryVel) -> bool;
    fn robot_interfaces__msg__GantryVel__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GantryVel>, size: usize) -> bool;
    fn robot_interfaces__msg__GantryVel__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GantryVel>);
    fn robot_interfaces__msg__GantryVel__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GantryVel>, out_seq: *mut rosidl_runtime_rs::Sequence<GantryVel>) -> bool;
}

// Corresponds to robot_interfaces__msg__GantryVel
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GantryVel {

    // This member is not documented.
    #[allow(missing_docs)]
    pub gantry_vel: f32,

}



impl Default for GantryVel {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__GantryVel__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__GantryVel__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GantryVel {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__GantryVel__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__GantryVel__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__GantryVel__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GantryVel {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GantryVel where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/GantryVel";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__GantryVel() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Jenc() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__Jenc__init(msg: *mut Jenc) -> bool;
    fn robot_interfaces__msg__Jenc__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Jenc>, size: usize) -> bool;
    fn robot_interfaces__msg__Jenc__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Jenc>);
    fn robot_interfaces__msg__Jenc__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Jenc>, out_seq: *mut rosidl_runtime_rs::Sequence<Jenc>) -> bool;
}

// Corresponds to robot_interfaces__msg__Jenc
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Jenc {

    // This member is not documented.
    #[allow(missing_docs)]
    pub ticks: i32,

}



impl Default for Jenc {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__Jenc__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__Jenc__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Jenc {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Jenc__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Jenc__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__Jenc__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Jenc {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Jenc where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/Jenc";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__Jenc() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__JmotorVelocity() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__JmotorVelocity__init(msg: *mut JmotorVelocity) -> bool;
    fn robot_interfaces__msg__JmotorVelocity__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<JmotorVelocity>, size: usize) -> bool;
    fn robot_interfaces__msg__JmotorVelocity__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<JmotorVelocity>);
    fn robot_interfaces__msg__JmotorVelocity__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<JmotorVelocity>, out_seq: *mut rosidl_runtime_rs::Sequence<JmotorVelocity>) -> bool;
}

// Corresponds to robot_interfaces__msg__JmotorVelocity
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct JmotorVelocity {

    // This member is not documented.
    #[allow(missing_docs)]
    pub j1: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub j2: i32,

}



impl Default for JmotorVelocity {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__JmotorVelocity__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__JmotorVelocity__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for JmotorVelocity {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__JmotorVelocity__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__JmotorVelocity__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__JmotorVelocity__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for JmotorVelocity {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for JmotorVelocity where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/JmotorVelocity";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__JmotorVelocity() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__ReedSwitch() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__ReedSwitch__init(msg: *mut ReedSwitch) -> bool;
    fn robot_interfaces__msg__ReedSwitch__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ReedSwitch>, size: usize) -> bool;
    fn robot_interfaces__msg__ReedSwitch__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ReedSwitch>);
    fn robot_interfaces__msg__ReedSwitch__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ReedSwitch>, out_seq: *mut rosidl_runtime_rs::Sequence<ReedSwitch>) -> bool;
}

// Corresponds to robot_interfaces__msg__ReedSwitch
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ReedSwitch {

    // This member is not documented.
    #[allow(missing_docs)]
    pub top: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bottom: i32,

}



impl Default for ReedSwitch {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__ReedSwitch__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__ReedSwitch__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ReedSwitch {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ReedSwitch__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ReedSwitch__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__ReedSwitch__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ReedSwitch {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ReedSwitch where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/ReedSwitch";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__ReedSwitch() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__SpearheadgripperTOF() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__msg__SpearheadgripperTOF__init(msg: *mut SpearheadgripperTOF) -> bool;
    fn robot_interfaces__msg__SpearheadgripperTOF__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SpearheadgripperTOF>, size: usize) -> bool;
    fn robot_interfaces__msg__SpearheadgripperTOF__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SpearheadgripperTOF>);
    fn robot_interfaces__msg__SpearheadgripperTOF__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SpearheadgripperTOF>, out_seq: *mut rosidl_runtime_rs::Sequence<SpearheadgripperTOF>) -> bool;
}

// Corresponds to robot_interfaces__msg__SpearheadgripperTOF
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SpearheadgripperTOF {

    // This member is not documented.
    #[allow(missing_docs)]
    pub sensor1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sensor2: f32,

}



impl Default for SpearheadgripperTOF {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__msg__SpearheadgripperTOF__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__msg__SpearheadgripperTOF__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SpearheadgripperTOF {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__SpearheadgripperTOF__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__SpearheadgripperTOF__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__msg__SpearheadgripperTOF__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SpearheadgripperTOF {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SpearheadgripperTOF where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/msg/SpearheadgripperTOF";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__msg__SpearheadgripperTOF() }
  }
}


