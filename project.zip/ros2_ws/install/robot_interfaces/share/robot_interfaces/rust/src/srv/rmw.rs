#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__ServiceCall_Request() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__srv__ServiceCall_Request__init(msg: *mut ServiceCall_Request) -> bool;
    fn robot_interfaces__srv__ServiceCall_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ServiceCall_Request>, size: usize) -> bool;
    fn robot_interfaces__srv__ServiceCall_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ServiceCall_Request>);
    fn robot_interfaces__srv__ServiceCall_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ServiceCall_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<ServiceCall_Request>) -> bool;
}

// Corresponds to robot_interfaces__srv__ServiceCall_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ServiceCall_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub bot_status: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub climb_mode: i32,

}



impl Default for ServiceCall_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__srv__ServiceCall_Request__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__srv__ServiceCall_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ServiceCall_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__ServiceCall_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__ServiceCall_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__ServiceCall_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ServiceCall_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ServiceCall_Request where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/srv/ServiceCall_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__ServiceCall_Request() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__ServiceCall_Response() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__srv__ServiceCall_Response__init(msg: *mut ServiceCall_Response) -> bool;
    fn robot_interfaces__srv__ServiceCall_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ServiceCall_Response>, size: usize) -> bool;
    fn robot_interfaces__srv__ServiceCall_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ServiceCall_Response>);
    fn robot_interfaces__srv__ServiceCall_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ServiceCall_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<ServiceCall_Response>) -> bool;
}

// Corresponds to robot_interfaces__srv__ServiceCall_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ServiceCall_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: i16,

}



impl Default for ServiceCall_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__srv__ServiceCall_Response__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__srv__ServiceCall_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ServiceCall_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__ServiceCall_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__ServiceCall_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__ServiceCall_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ServiceCall_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ServiceCall_Response where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/srv/ServiceCall_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__ServiceCall_Response() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__KfsServicePickup_Request() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__srv__KfsServicePickup_Request__init(msg: *mut KfsServicePickup_Request) -> bool;
    fn robot_interfaces__srv__KfsServicePickup_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<KfsServicePickup_Request>, size: usize) -> bool;
    fn robot_interfaces__srv__KfsServicePickup_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<KfsServicePickup_Request>);
    fn robot_interfaces__srv__KfsServicePickup_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<KfsServicePickup_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<KfsServicePickup_Request>) -> bool;
}

// Corresponds to robot_interfaces__srv__KfsServicePickup_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct KfsServicePickup_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub bot_status: i32,

    /// -1 for lower and 1 for upper pickupstates
    pub pickupstate: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub target_height: i32,

}



impl Default for KfsServicePickup_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__srv__KfsServicePickup_Request__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__srv__KfsServicePickup_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for KfsServicePickup_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__KfsServicePickup_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__KfsServicePickup_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__KfsServicePickup_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for KfsServicePickup_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for KfsServicePickup_Request where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/srv/KfsServicePickup_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__KfsServicePickup_Request() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__KfsServicePickup_Response() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__srv__KfsServicePickup_Response__init(msg: *mut KfsServicePickup_Response) -> bool;
    fn robot_interfaces__srv__KfsServicePickup_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<KfsServicePickup_Response>, size: usize) -> bool;
    fn robot_interfaces__srv__KfsServicePickup_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<KfsServicePickup_Response>);
    fn robot_interfaces__srv__KfsServicePickup_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<KfsServicePickup_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<KfsServicePickup_Response>) -> bool;
}

// Corresponds to robot_interfaces__srv__KfsServicePickup_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct KfsServicePickup_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub response: i32,

}



impl Default for KfsServicePickup_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__srv__KfsServicePickup_Response__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__srv__KfsServicePickup_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for KfsServicePickup_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__KfsServicePickup_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__KfsServicePickup_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__KfsServicePickup_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for KfsServicePickup_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for KfsServicePickup_Response where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/srv/KfsServicePickup_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__KfsServicePickup_Response() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__PickSpearhead_Request() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__srv__PickSpearhead_Request__init(msg: *mut PickSpearhead_Request) -> bool;
    fn robot_interfaces__srv__PickSpearhead_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PickSpearhead_Request>, size: usize) -> bool;
    fn robot_interfaces__srv__PickSpearhead_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PickSpearhead_Request>);
    fn robot_interfaces__srv__PickSpearhead_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PickSpearhead_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<PickSpearhead_Request>) -> bool;
}

// Corresponds to robot_interfaces__srv__PickSpearhead_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PickSpearhead_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub start: bool,

}



impl Default for PickSpearhead_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__srv__PickSpearhead_Request__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__srv__PickSpearhead_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PickSpearhead_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__PickSpearhead_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__PickSpearhead_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__PickSpearhead_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PickSpearhead_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PickSpearhead_Request where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/srv/PickSpearhead_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__PickSpearhead_Request() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__PickSpearhead_Response() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__srv__PickSpearhead_Response__init(msg: *mut PickSpearhead_Response) -> bool;
    fn robot_interfaces__srv__PickSpearhead_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PickSpearhead_Response>, size: usize) -> bool;
    fn robot_interfaces__srv__PickSpearhead_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PickSpearhead_Response>);
    fn robot_interfaces__srv__PickSpearhead_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PickSpearhead_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<PickSpearhead_Response>) -> bool;
}

// Corresponds to robot_interfaces__srv__PickSpearhead_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PickSpearhead_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for PickSpearhead_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__srv__PickSpearhead_Response__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__srv__PickSpearhead_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PickSpearhead_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__PickSpearhead_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__PickSpearhead_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__PickSpearhead_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PickSpearhead_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PickSpearhead_Response where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/srv/PickSpearhead_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__PickSpearhead_Response() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__CornerAlignService_Request() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__srv__CornerAlignService_Request__init(msg: *mut CornerAlignService_Request) -> bool;
    fn robot_interfaces__srv__CornerAlignService_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CornerAlignService_Request>, size: usize) -> bool;
    fn robot_interfaces__srv__CornerAlignService_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CornerAlignService_Request>);
    fn robot_interfaces__srv__CornerAlignService_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CornerAlignService_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<CornerAlignService_Request>) -> bool;
}

// Corresponds to robot_interfaces__srv__CornerAlignService_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CornerAlignService_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub command: i32,

    /// right or left
    pub mode: rosidl_runtime_rs::String,

}



impl Default for CornerAlignService_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__srv__CornerAlignService_Request__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__srv__CornerAlignService_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CornerAlignService_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__CornerAlignService_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__CornerAlignService_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__CornerAlignService_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CornerAlignService_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CornerAlignService_Request where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/srv/CornerAlignService_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__CornerAlignService_Request() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__CornerAlignService_Response() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__srv__CornerAlignService_Response__init(msg: *mut CornerAlignService_Response) -> bool;
    fn robot_interfaces__srv__CornerAlignService_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CornerAlignService_Response>, size: usize) -> bool;
    fn robot_interfaces__srv__CornerAlignService_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CornerAlignService_Response>);
    fn robot_interfaces__srv__CornerAlignService_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CornerAlignService_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<CornerAlignService_Response>) -> bool;
}

// Corresponds to robot_interfaces__srv__CornerAlignService_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CornerAlignService_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub response: i32,

}



impl Default for CornerAlignService_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__srv__CornerAlignService_Response__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__srv__CornerAlignService_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CornerAlignService_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__CornerAlignService_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__CornerAlignService_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__CornerAlignService_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CornerAlignService_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CornerAlignService_Response where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/srv/CornerAlignService_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__CornerAlignService_Response() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__Zone3Detect_Request() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__srv__Zone3Detect_Request__init(msg: *mut Zone3Detect_Request) -> bool;
    fn robot_interfaces__srv__Zone3Detect_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Zone3Detect_Request>, size: usize) -> bool;
    fn robot_interfaces__srv__Zone3Detect_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Zone3Detect_Request>);
    fn robot_interfaces__srv__Zone3Detect_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Zone3Detect_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<Zone3Detect_Request>) -> bool;
}

// Corresponds to robot_interfaces__srv__Zone3Detect_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Zone3Detect_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub req: i32,

}



impl Default for Zone3Detect_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__srv__Zone3Detect_Request__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__srv__Zone3Detect_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Zone3Detect_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__Zone3Detect_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__Zone3Detect_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__Zone3Detect_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Zone3Detect_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Zone3Detect_Request where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/srv/Zone3Detect_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__Zone3Detect_Request() }
  }
}


#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__Zone3Detect_Response() -> *const std::ffi::c_void;
}

#[link(name = "robot_interfaces__rosidl_generator_c")]
extern "C" {
    fn robot_interfaces__srv__Zone3Detect_Response__init(msg: *mut Zone3Detect_Response) -> bool;
    fn robot_interfaces__srv__Zone3Detect_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Zone3Detect_Response>, size: usize) -> bool;
    fn robot_interfaces__srv__Zone3Detect_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Zone3Detect_Response>);
    fn robot_interfaces__srv__Zone3Detect_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Zone3Detect_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<Zone3Detect_Response>) -> bool;
}

// Corresponds to robot_interfaces__srv__Zone3Detect_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Zone3Detect_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub present: bool,

}



impl Default for Zone3Detect_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !robot_interfaces__srv__Zone3Detect_Response__init(&mut msg as *mut _) {
        panic!("Call to robot_interfaces__srv__Zone3Detect_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Zone3Detect_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__Zone3Detect_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__Zone3Detect_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { robot_interfaces__srv__Zone3Detect_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Zone3Detect_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Zone3Detect_Response where Self: Sized {
  const TYPE_NAME: &'static str = "robot_interfaces/srv/Zone3Detect_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__robot_interfaces__srv__Zone3Detect_Response() }
  }
}






#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__ServiceCall() -> *const std::ffi::c_void;
}

// Corresponds to robot_interfaces__srv__ServiceCall
#[allow(missing_docs, non_camel_case_types)]
pub struct ServiceCall;

impl rosidl_runtime_rs::Service for ServiceCall {
    type Request = ServiceCall_Request;
    type Response = ServiceCall_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__ServiceCall() }
    }
}




#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__KfsServicePickup() -> *const std::ffi::c_void;
}

// Corresponds to robot_interfaces__srv__KfsServicePickup
#[allow(missing_docs, non_camel_case_types)]
pub struct KfsServicePickup;

impl rosidl_runtime_rs::Service for KfsServicePickup {
    type Request = KfsServicePickup_Request;
    type Response = KfsServicePickup_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__KfsServicePickup() }
    }
}




#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__PickSpearhead() -> *const std::ffi::c_void;
}

// Corresponds to robot_interfaces__srv__PickSpearhead
#[allow(missing_docs, non_camel_case_types)]
pub struct PickSpearhead;

impl rosidl_runtime_rs::Service for PickSpearhead {
    type Request = PickSpearhead_Request;
    type Response = PickSpearhead_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__PickSpearhead() }
    }
}




#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__CornerAlignService() -> *const std::ffi::c_void;
}

// Corresponds to robot_interfaces__srv__CornerAlignService
#[allow(missing_docs, non_camel_case_types)]
pub struct CornerAlignService;

impl rosidl_runtime_rs::Service for CornerAlignService {
    type Request = CornerAlignService_Request;
    type Response = CornerAlignService_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__CornerAlignService() }
    }
}




#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__Zone3Detect() -> *const std::ffi::c_void;
}

// Corresponds to robot_interfaces__srv__Zone3Detect
#[allow(missing_docs, non_camel_case_types)]
pub struct Zone3Detect;

impl rosidl_runtime_rs::Service for Zone3Detect {
    type Request = Zone3Detect_Request;
    type Response = Zone3Detect_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__Zone3Detect() }
    }
}


