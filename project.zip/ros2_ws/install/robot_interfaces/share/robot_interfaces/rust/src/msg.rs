#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to robot_interfaces__msg__BnoReading

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BnoReading {

    // This member is not documented.
    #[allow(missing_docs)]
    pub current_angle: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pitch: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub roll: f32,

}



impl Default for BnoReading {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::BnoReading::default())
  }
}

impl rosidl_runtime_rs::Message for BnoReading {
  type RmwMsg = super::msg::rmw::BnoReading;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        current_angle: msg.current_angle,
        pitch: msg.pitch,
        roll: msg.roll,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      current_angle: msg.current_angle,
      pitch: msg.pitch,
      roll: msg.roll,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      current_angle: msg.current_angle,
      pitch: msg.pitch,
      roll: msg.roll,
    }
  }
}


// Corresponds to robot_interfaces__msg__Encoder

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Encoder {

    // This member is not documented.
    #[allow(missing_docs)]
    pub xticks: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub yticks: i32,

}



impl Default for Encoder {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Encoder::default())
  }
}

impl rosidl_runtime_rs::Message for Encoder {
  type RmwMsg = super::msg::rmw::Encoder;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        xticks: msg.xticks,
        yticks: msg.yticks,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      xticks: msg.xticks,
      yticks: msg.yticks,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      xticks: msg.xticks,
      yticks: msg.yticks,
    }
  }
}


// Corresponds to robot_interfaces__msg__Lidar

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Lidar {

    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_front: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_back: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_left: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_right: f32,

}



impl Default for Lidar {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Lidar::default())
  }
}

impl rosidl_runtime_rs::Message for Lidar {
  type RmwMsg = super::msg::rmw::Lidar;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        lidar_front: msg.lidar_front,
        lidar_back: msg.lidar_back,
        lidar_left: msg.lidar_left,
        lidar_right: msg.lidar_right,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      lidar_front: msg.lidar_front,
      lidar_back: msg.lidar_back,
      lidar_left: msg.lidar_left,
      lidar_right: msg.lidar_right,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      lidar_front: msg.lidar_front,
      lidar_back: msg.lidar_back,
      lidar_left: msg.lidar_left,
      lidar_right: msg.lidar_right,
    }
  }
}


// Corresponds to robot_interfaces__msg__LimitSwitch

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LimitSwitch {

    // This member is not documented.
    #[allow(missing_docs)]
    pub ls1: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ls2: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ls3: i32,

}



impl Default for LimitSwitch {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LimitSwitch::default())
  }
}

impl rosidl_runtime_rs::Message for LimitSwitch {
  type RmwMsg = super::msg::rmw::LimitSwitch;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        ls1: msg.ls1,
        ls2: msg.ls2,
        ls3: msg.ls3,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      ls1: msg.ls1,
      ls2: msg.ls2,
      ls3: msg.ls3,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      ls1: msg.ls1,
      ls2: msg.ls2,
      ls3: msg.ls3,
    }
  }
}


// Corresponds to robot_interfaces__msg__Velocity

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Velocity {

    // This member is not documented.
    #[allow(missing_docs)]
    pub vx: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub vy: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub vw: f32,

}



impl Default for Velocity {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Velocity::default())
  }
}

impl rosidl_runtime_rs::Message for Velocity {
  type RmwMsg = super::msg::rmw::Velocity;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        vx: msg.vx,
        vy: msg.vy,
        vw: msg.vw,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      vx: msg.vx,
      vy: msg.vy,
      vw: msg.vw,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      vx: msg.vx,
      vy: msg.vy,
      vw: msg.vw,
    }
  }
}


// Corresponds to robot_interfaces__msg__BallScrew
/// Ball Screw motor commands (ROS -> MCU)
/// -1 = lower, 0 is stop, 1 = raise

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct BallScrew {

    // This member is not documented.
    #[allow(missing_docs)]
    pub front_cmd: i8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub back_cmd: i8,

}



impl Default for BallScrew {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::BallScrew::default())
  }
}

impl rosidl_runtime_rs::Message for BallScrew {
  type RmwMsg = super::msg::rmw::BallScrew;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        front_cmd: msg.front_cmd,
        back_cmd: msg.back_cmd,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      front_cmd: msg.front_cmd,
      back_cmd: msg.back_cmd,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      front_cmd: msg.front_cmd,
      back_cmd: msg.back_cmd,
    }
  }
}


// Corresponds to robot_interfaces__msg__ClimbMotors
/// Climb motor velocities (ROS -> MCU)
/// For the 2 climb wheel motors
/// To go front and back on your secondary drive 

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ClimbMotors {

    // This member is not documented.
    #[allow(missing_docs)]
    pub front_velocity: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub back_velocity: f32,

}



impl Default for ClimbMotors {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ClimbMotors::default())
  }
}

impl rosidl_runtime_rs::Message for ClimbMotors {
  type RmwMsg = super::msg::rmw::ClimbMotors;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        front_velocity: msg.front_velocity,
        back_velocity: msg.back_velocity,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      front_velocity: msg.front_velocity,
      back_velocity: msg.back_velocity,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      front_velocity: msg.front_velocity,
      back_velocity: msg.back_velocity,
    }
  }
}


// Corresponds to robot_interfaces__msg__Odom

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Odom {

    // This member is not documented.
    #[allow(missing_docs)]
    pub odom_x: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub odom_y: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub current_angle: f32,

}



impl Default for Odom {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Odom::default())
  }
}

impl rosidl_runtime_rs::Message for Odom {
  type RmwMsg = super::msg::rmw::Odom;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        odom_x: msg.odom_x,
        odom_y: msg.odom_y,
        current_angle: msg.current_angle,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      odom_x: msg.odom_x,
      odom_y: msg.odom_y,
      current_angle: msg.current_angle,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      odom_x: msg.odom_x,
      odom_y: msg.odom_y,
      current_angle: msg.current_angle,
    }
  }
}


// Corresponds to robot_interfaces__msg__Irsensors

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Irsensors {

    // This member is not documented.
    #[allow(missing_docs)]
    pub ir1: i16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ir2: i16,

}



impl Default for Irsensors {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Irsensors::default())
  }
}

impl rosidl_runtime_rs::Message for Irsensors {
  type RmwMsg = super::msg::rmw::Irsensors;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        ir1: msg.ir1,
        ir2: msg.ir2,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      ir1: msg.ir1,
      ir2: msg.ir2,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      ir1: msg.ir1,
      ir2: msg.ir2,
    }
  }
}


// Corresponds to robot_interfaces__msg__ServoSpearhead
/// Servo command for spearhead pickup mechanism
/// servo_finger: angle for finger/gripper servo (0-180)
/// servo_wrist: angle for wrist/rotation servo (0-180)

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ServoSpearhead {

    // This member is not documented.
    #[allow(missing_docs)]
    pub servo_finger: i16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub servo_wrist: i16,

}



impl Default for ServoSpearhead {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ServoSpearhead::default())
  }
}

impl rosidl_runtime_rs::Message for ServoSpearhead {
  type RmwMsg = super::msg::rmw::ServoSpearhead;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        servo_finger: msg.servo_finger,
        servo_wrist: msg.servo_wrist,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      servo_finger: msg.servo_finger,
      servo_wrist: msg.servo_wrist,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      servo_finger: msg.servo_finger,
      servo_wrist: msg.servo_wrist,
    }
  }
}


// Corresponds to robot_interfaces__msg__IR

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IR {

    // This member is not documented.
    #[allow(missing_docs)]
    pub irbot: i16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub irwall: i16,

}



impl Default for IR {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::IR::default())
  }
}

impl rosidl_runtime_rs::Message for IR {
  type RmwMsg = super::msg::rmw::IR;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        irbot: msg.irbot,
        irwall: msg.irwall,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      irbot: msg.irbot,
      irwall: msg.irwall,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      irbot: msg.irbot,
      irwall: msg.irwall,
    }
  }
}


// Corresponds to robot_interfaces__msg__ClimbJhonsonEnc

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ClimbJhonsonEnc {

    // This member is not documented.
    #[allow(missing_docs)]
    pub front_ticks: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub back_ticks: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub front_at_lower_limit: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub back_at_lower_limit: bool,

}



impl Default for ClimbJhonsonEnc {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ClimbJhonsonEnc::default())
  }
}

impl rosidl_runtime_rs::Message for ClimbJhonsonEnc {
  type RmwMsg = super::msg::rmw::ClimbJhonsonEnc;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        front_ticks: msg.front_ticks,
        back_ticks: msg.back_ticks,
        front_at_lower_limit: msg.front_at_lower_limit,
        back_at_lower_limit: msg.back_at_lower_limit,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      front_ticks: msg.front_ticks,
      back_ticks: msg.back_ticks,
      front_at_lower_limit: msg.front_at_lower_limit,
      back_at_lower_limit: msg.back_at_lower_limit,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      front_ticks: msg.front_ticks,
      back_ticks: msg.back_ticks,
      front_at_lower_limit: msg.front_at_lower_limit,
      back_at_lower_limit: msg.back_at_lower_limit,
    }
  }
}


// Corresponds to robot_interfaces__msg__GridData

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GridData {

    // This member is not documented.
    #[allow(missing_docs)]
    pub layout: [i32; 12],

}



impl Default for GridData {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::GridData::default())
  }
}

impl rosidl_runtime_rs::Message for GridData {
  type RmwMsg = super::msg::rmw::GridData;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        layout: msg.layout,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        layout: msg.layout,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      layout: msg.layout,
    }
  }
}


// Corresponds to robot_interfaces__msg__Grippers

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Grippers {

    // This member is not documented.
    #[allow(missing_docs)]
    pub gripper1: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub gripper2: bool,

}



impl Default for Grippers {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Grippers::default())
  }
}

impl rosidl_runtime_rs::Message for Grippers {
  type RmwMsg = super::msg::rmw::Grippers;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        gripper1: msg.gripper1,
        gripper2: msg.gripper2,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      gripper1: msg.gripper1,
      gripper2: msg.gripper2,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      gripper1: msg.gripper1,
      gripper2: msg.gripper2,
    }
  }
}


// Corresponds to robot_interfaces__msg__DepthIR

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DepthIR {
    /// for now assuming its aligned with global 90
    pub frontir: i16,

}



impl Default for DepthIR {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::DepthIR::default())
  }
}

impl rosidl_runtime_rs::Message for DepthIR {
  type RmwMsg = super::msg::rmw::DepthIR;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        frontir: msg.frontir,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      frontir: msg.frontir,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      frontir: msg.frontir,
    }
  }
}


// Corresponds to robot_interfaces__msg__ClimbIR

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ClimbIR {

    // This member is not documented.
    #[allow(missing_docs)]
    pub front_wheel: i16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub back_wheel: i16,

}



impl Default for ClimbIR {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ClimbIR::default())
  }
}

impl rosidl_runtime_rs::Message for ClimbIR {
  type RmwMsg = super::msg::rmw::ClimbIR;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        front_wheel: msg.front_wheel,
        back_wheel: msg.back_wheel,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      front_wheel: msg.front_wheel,
      back_wheel: msg.back_wheel,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      front_wheel: msg.front_wheel,
      back_wheel: msg.back_wheel,
    }
  }
}


// Corresponds to robot_interfaces__msg__KfsServiceLimitSwitch

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct KfsServiceLimitSwitch {

    // This member is not documented.
    #[allow(missing_docs)]
    pub limit_switch_front: i16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub limit_switch_backs: i16,

}



impl Default for KfsServiceLimitSwitch {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::KfsServiceLimitSwitch::default())
  }
}

impl rosidl_runtime_rs::Message for KfsServiceLimitSwitch {
  type RmwMsg = super::msg::rmw::KfsServiceLimitSwitch;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        limit_switch_front: msg.limit_switch_front,
        limit_switch_backs: msg.limit_switch_backs,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      limit_switch_front: msg.limit_switch_front,
      limit_switch_backs: msg.limit_switch_backs,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      limit_switch_front: msg.limit_switch_front,
      limit_switch_backs: msg.limit_switch_backs,
    }
  }
}


// Corresponds to robot_interfaces__msg__GantryVel

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GantryVel {

    // This member is not documented.
    #[allow(missing_docs)]
    pub gantry_vel: f32,

}



impl Default for GantryVel {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::GantryVel::default())
  }
}

impl rosidl_runtime_rs::Message for GantryVel {
  type RmwMsg = super::msg::rmw::GantryVel;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        gantry_vel: msg.gantry_vel,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      gantry_vel: msg.gantry_vel,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      gantry_vel: msg.gantry_vel,
    }
  }
}


// Corresponds to robot_interfaces__msg__Jenc

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Jenc {

    // This member is not documented.
    #[allow(missing_docs)]
    pub ticks: i32,

}



impl Default for Jenc {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Jenc::default())
  }
}

impl rosidl_runtime_rs::Message for Jenc {
  type RmwMsg = super::msg::rmw::Jenc;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        ticks: msg.ticks,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      ticks: msg.ticks,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      ticks: msg.ticks,
    }
  }
}


// Corresponds to robot_interfaces__msg__JmotorVelocity

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct JmotorVelocity {

    // This member is not documented.
    #[allow(missing_docs)]
    pub j1: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub j2: i32,

}



impl Default for JmotorVelocity {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::JmotorVelocity::default())
  }
}

impl rosidl_runtime_rs::Message for JmotorVelocity {
  type RmwMsg = super::msg::rmw::JmotorVelocity;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        j1: msg.j1,
        j2: msg.j2,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      j1: msg.j1,
      j2: msg.j2,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      j1: msg.j1,
      j2: msg.j2,
    }
  }
}


// Corresponds to robot_interfaces__msg__ReedSwitch

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ReedSwitch {

    // This member is not documented.
    #[allow(missing_docs)]
    pub top: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub bottom: i32,

}



impl Default for ReedSwitch {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ReedSwitch::default())
  }
}

impl rosidl_runtime_rs::Message for ReedSwitch {
  type RmwMsg = super::msg::rmw::ReedSwitch;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        top: msg.top,
        bottom: msg.bottom,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      top: msg.top,
      bottom: msg.bottom,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      top: msg.top,
      bottom: msg.bottom,
    }
  }
}


// Corresponds to robot_interfaces__msg__SpearheadgripperTOF

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SpearheadgripperTOF {

    // This member is not documented.
    #[allow(missing_docs)]
    pub sensor1: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sensor2: f32,

}



impl Default for SpearheadgripperTOF {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::SpearheadgripperTOF::default())
  }
}

impl rosidl_runtime_rs::Message for SpearheadgripperTOF {
  type RmwMsg = super::msg::rmw::SpearheadgripperTOF;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        sensor1: msg.sensor1,
        sensor2: msg.sensor2,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      sensor1: msg.sensor1,
      sensor2: msg.sensor2,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      sensor1: msg.sensor1,
      sensor2: msg.sensor2,
    }
  }
}


