#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};




// Corresponds to robot_interfaces__srv__ServiceCall_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ServiceCall_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub bot_status: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub climb_mode: i32,

}



impl Default for ServiceCall_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ServiceCall_Request::default())
  }
}

impl rosidl_runtime_rs::Message for ServiceCall_Request {
  type RmwMsg = super::srv::rmw::ServiceCall_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        bot_status: msg.bot_status,
        climb_mode: msg.climb_mode,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      bot_status: msg.bot_status,
      climb_mode: msg.climb_mode,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      bot_status: msg.bot_status,
      climb_mode: msg.climb_mode,
    }
  }
}


// Corresponds to robot_interfaces__srv__ServiceCall_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ServiceCall_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: i16,

}



impl Default for ServiceCall_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ServiceCall_Response::default())
  }
}

impl rosidl_runtime_rs::Message for ServiceCall_Response {
  type RmwMsg = super::srv::rmw::ServiceCall_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
    }
  }
}


// Corresponds to robot_interfaces__srv__KfsServicePickup_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct KfsServicePickup_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub bot_status: i32,

    /// -1 for lower and 1 for upper pickupstates
    pub pickupstate: i32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub target_height: i32,

}



impl Default for KfsServicePickup_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::KfsServicePickup_Request::default())
  }
}

impl rosidl_runtime_rs::Message for KfsServicePickup_Request {
  type RmwMsg = super::srv::rmw::KfsServicePickup_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        bot_status: msg.bot_status,
        pickupstate: msg.pickupstate,
        target_height: msg.target_height,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      bot_status: msg.bot_status,
      pickupstate: msg.pickupstate,
      target_height: msg.target_height,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      bot_status: msg.bot_status,
      pickupstate: msg.pickupstate,
      target_height: msg.target_height,
    }
  }
}


// Corresponds to robot_interfaces__srv__KfsServicePickup_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct KfsServicePickup_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub response: i32,

}



impl Default for KfsServicePickup_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::KfsServicePickup_Response::default())
  }
}

impl rosidl_runtime_rs::Message for KfsServicePickup_Response {
  type RmwMsg = super::srv::rmw::KfsServicePickup_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: msg.response,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      response: msg.response,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      response: msg.response,
    }
  }
}


// Corresponds to robot_interfaces__srv__PickSpearhead_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PickSpearhead_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub start: bool,

}



impl Default for PickSpearhead_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::PickSpearhead_Request::default())
  }
}

impl rosidl_runtime_rs::Message for PickSpearhead_Request {
  type RmwMsg = super::srv::rmw::PickSpearhead_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        start: msg.start,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      start: msg.start,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      start: msg.start,
    }
  }
}


// Corresponds to robot_interfaces__srv__PickSpearhead_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PickSpearhead_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for PickSpearhead_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::PickSpearhead_Response::default())
  }
}

impl rosidl_runtime_rs::Message for PickSpearhead_Response {
  type RmwMsg = super::srv::rmw::PickSpearhead_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}


// Corresponds to robot_interfaces__srv__CornerAlignService_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CornerAlignService_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub command: i32,

    /// right or left
    pub mode: std::string::String,

}



impl Default for CornerAlignService_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CornerAlignService_Request::default())
  }
}

impl rosidl_runtime_rs::Message for CornerAlignService_Request {
  type RmwMsg = super::srv::rmw::CornerAlignService_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        command: msg.command,
        mode: msg.mode.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      command: msg.command,
        mode: msg.mode.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      command: msg.command,
      mode: msg.mode.to_string(),
    }
  }
}


// Corresponds to robot_interfaces__srv__CornerAlignService_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CornerAlignService_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub response: i32,

}



impl Default for CornerAlignService_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::CornerAlignService_Response::default())
  }
}

impl rosidl_runtime_rs::Message for CornerAlignService_Response {
  type RmwMsg = super::srv::rmw::CornerAlignService_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        response: msg.response,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      response: msg.response,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      response: msg.response,
    }
  }
}


// Corresponds to robot_interfaces__srv__Zone3Detect_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Zone3Detect_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub req: i32,

}



impl Default for Zone3Detect_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::Zone3Detect_Request::default())
  }
}

impl rosidl_runtime_rs::Message for Zone3Detect_Request {
  type RmwMsg = super::srv::rmw::Zone3Detect_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        req: msg.req,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      req: msg.req,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      req: msg.req,
    }
  }
}


// Corresponds to robot_interfaces__srv__Zone3Detect_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Zone3Detect_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub present: bool,

}



impl Default for Zone3Detect_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::Zone3Detect_Response::default())
  }
}

impl rosidl_runtime_rs::Message for Zone3Detect_Response {
  type RmwMsg = super::srv::rmw::Zone3Detect_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        present: msg.present,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      present: msg.present,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      present: msg.present,
    }
  }
}






#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__ServiceCall() -> *const std::ffi::c_void;
}

// Corresponds to robot_interfaces__srv__ServiceCall
#[allow(missing_docs, non_camel_case_types)]
pub struct ServiceCall;

impl rosidl_runtime_rs::Service for ServiceCall {
    type Request = ServiceCall_Request;
    type Response = ServiceCall_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__ServiceCall() }
    }
}




#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__KfsServicePickup() -> *const std::ffi::c_void;
}

// Corresponds to robot_interfaces__srv__KfsServicePickup
#[allow(missing_docs, non_camel_case_types)]
pub struct KfsServicePickup;

impl rosidl_runtime_rs::Service for KfsServicePickup {
    type Request = KfsServicePickup_Request;
    type Response = KfsServicePickup_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__KfsServicePickup() }
    }
}




#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__PickSpearhead() -> *const std::ffi::c_void;
}

// Corresponds to robot_interfaces__srv__PickSpearhead
#[allow(missing_docs, non_camel_case_types)]
pub struct PickSpearhead;

impl rosidl_runtime_rs::Service for PickSpearhead {
    type Request = PickSpearhead_Request;
    type Response = PickSpearhead_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__PickSpearhead() }
    }
}




#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__CornerAlignService() -> *const std::ffi::c_void;
}

// Corresponds to robot_interfaces__srv__CornerAlignService
#[allow(missing_docs, non_camel_case_types)]
pub struct CornerAlignService;

impl rosidl_runtime_rs::Service for CornerAlignService {
    type Request = CornerAlignService_Request;
    type Response = CornerAlignService_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__CornerAlignService() }
    }
}




#[link(name = "robot_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__Zone3Detect() -> *const std::ffi::c_void;
}

// Corresponds to robot_interfaces__srv__Zone3Detect
#[allow(missing_docs, non_camel_case_types)]
pub struct Zone3Detect;

impl rosidl_runtime_rs::Service for Zone3Detect {
    type Request = Zone3Detect_Request;
    type Response = Zone3Detect_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__robot_interfaces__srv__Zone3Detect() }
    }
}


