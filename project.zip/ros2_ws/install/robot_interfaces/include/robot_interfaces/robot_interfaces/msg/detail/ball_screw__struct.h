// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:msg/BallScrew.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/ball_screw.h"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__BALL_SCREW__STRUCT_H_
#define ROBOT_INTERFACES__MSG__DETAIL__BALL_SCREW__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/BallScrew in the package robot_interfaces.
/**
  * Ball Screw motor commands (ROS -> MCU)
  * -1 = lower, 0 is stop, 1 = raise
 */
typedef struct robot_interfaces__msg__BallScrew
{
  int8_t front_cmd;
  int8_t back_cmd;
} robot_interfaces__msg__BallScrew;

// Struct for a sequence of robot_interfaces__msg__BallScrew.
typedef struct robot_interfaces__msg__BallScrew__Sequence
{
  robot_interfaces__msg__BallScrew * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__msg__BallScrew__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__MSG__DETAIL__BALL_SCREW__STRUCT_H_
