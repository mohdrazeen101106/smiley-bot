// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/ClimbIR.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/climb_ir.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__CLIMB_IR__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__CLIMB_IR__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__ClimbIR __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__ClimbIR __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ClimbIR_
{
  using Type = ClimbIR_<ContainerAllocator>;

  explicit ClimbIR_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_wheel = 0;
      this->back_wheel = 0;
    }
  }

  explicit ClimbIR_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_wheel = 0;
      this->back_wheel = 0;
    }
  }

  // field types and members
  using _front_wheel_type =
    int16_t;
  _front_wheel_type front_wheel;
  using _back_wheel_type =
    int16_t;
  _back_wheel_type back_wheel;

  // setters for named parameter idiom
  Type & set__front_wheel(
    const int16_t & _arg)
  {
    this->front_wheel = _arg;
    return *this;
  }
  Type & set__back_wheel(
    const int16_t & _arg)
  {
    this->back_wheel = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::ClimbIR_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::ClimbIR_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::ClimbIR_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::ClimbIR_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::ClimbIR_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::ClimbIR_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::ClimbIR_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::ClimbIR_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::ClimbIR_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::ClimbIR_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__ClimbIR
    std::shared_ptr<robot_interfaces::msg::ClimbIR_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__ClimbIR
    std::shared_ptr<robot_interfaces::msg::ClimbIR_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ClimbIR_ & other) const
  {
    if (this->front_wheel != other.front_wheel) {
      return false;
    }
    if (this->back_wheel != other.back_wheel) {
      return false;
    }
    return true;
  }
  bool operator!=(const ClimbIR_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ClimbIR_

// alias to use template instance with default allocator
using ClimbIR =
  robot_interfaces::msg::ClimbIR_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__CLIMB_IR__STRUCT_HPP_
