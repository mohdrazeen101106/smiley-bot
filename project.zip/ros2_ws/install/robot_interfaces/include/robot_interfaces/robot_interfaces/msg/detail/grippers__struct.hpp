// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/Grippers.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/grippers.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__GRIPPERS__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__GRIPPERS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__Grippers __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__Grippers __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Grippers_
{
  using Type = Grippers_<ContainerAllocator>;

  explicit Grippers_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->gripper1 = false;
      this->gripper2 = false;
    }
  }

  explicit Grippers_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->gripper1 = false;
      this->gripper2 = false;
    }
  }

  // field types and members
  using _gripper1_type =
    bool;
  _gripper1_type gripper1;
  using _gripper2_type =
    bool;
  _gripper2_type gripper2;

  // setters for named parameter idiom
  Type & set__gripper1(
    const bool & _arg)
  {
    this->gripper1 = _arg;
    return *this;
  }
  Type & set__gripper2(
    const bool & _arg)
  {
    this->gripper2 = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::Grippers_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::Grippers_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::Grippers_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::Grippers_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::Grippers_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::Grippers_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::Grippers_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::Grippers_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::Grippers_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::Grippers_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__Grippers
    std::shared_ptr<robot_interfaces::msg::Grippers_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__Grippers
    std::shared_ptr<robot_interfaces::msg::Grippers_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Grippers_ & other) const
  {
    if (this->gripper1 != other.gripper1) {
      return false;
    }
    if (this->gripper2 != other.gripper2) {
      return false;
    }
    return true;
  }
  bool operator!=(const Grippers_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Grippers_

// alias to use template instance with default allocator
using Grippers =
  robot_interfaces::msg::Grippers_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__GRIPPERS__STRUCT_HPP_
