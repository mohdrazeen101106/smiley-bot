// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/DepthIR.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/depth_ir.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__DEPTH_IR__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__DEPTH_IR__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__DepthIR __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__DepthIR __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DepthIR_
{
  using Type = DepthIR_<ContainerAllocator>;

  explicit DepthIR_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->frontir = 0;
    }
  }

  explicit DepthIR_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->frontir = 0;
    }
  }

  // field types and members
  using _frontir_type =
    int16_t;
  _frontir_type frontir;

  // setters for named parameter idiom
  Type & set__frontir(
    const int16_t & _arg)
  {
    this->frontir = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::DepthIR_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::DepthIR_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::DepthIR_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::DepthIR_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::DepthIR_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::DepthIR_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::DepthIR_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::DepthIR_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::DepthIR_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::DepthIR_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__DepthIR
    std::shared_ptr<robot_interfaces::msg::DepthIR_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__DepthIR
    std::shared_ptr<robot_interfaces::msg::DepthIR_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DepthIR_ & other) const
  {
    if (this->frontir != other.frontir) {
      return false;
    }
    return true;
  }
  bool operator!=(const DepthIR_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DepthIR_

// alias to use template instance with default allocator
using DepthIR =
  robot_interfaces::msg::DepthIR_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__DEPTH_IR__STRUCT_HPP_
