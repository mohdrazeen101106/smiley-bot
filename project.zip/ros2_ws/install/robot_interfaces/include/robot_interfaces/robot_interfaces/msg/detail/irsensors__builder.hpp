// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/Irsensors.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/irsensors.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__IRSENSORS__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__IRSENSORS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/irsensors__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_Irsensors_ir2
{
public:
  explicit Init_Irsensors_ir2(::robot_interfaces::msg::Irsensors & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::Irsensors ir2(::robot_interfaces::msg::Irsensors::_ir2_type arg)
  {
    msg_.ir2 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::Irsensors msg_;
};

class Init_Irsensors_ir1
{
public:
  Init_Irsensors_ir1()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Irsensors_ir2 ir1(::robot_interfaces::msg::Irsensors::_ir1_type arg)
  {
    msg_.ir1 = std::move(arg);
    return Init_Irsensors_ir2(msg_);
  }

private:
  ::robot_interfaces::msg::Irsensors msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::Irsensors>()
{
  return robot_interfaces::msg::builder::Init_Irsensors_ir1();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__IRSENSORS__BUILDER_HPP_
