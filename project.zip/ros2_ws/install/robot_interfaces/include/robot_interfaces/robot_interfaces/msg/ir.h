// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:msg/IR.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__IR_H_
#define ROBOT_INTERFACES__MSG__IR_H_

#include "robot_interfaces/msg/detail/ir__struct.h"
#include "robot_interfaces/msg/detail/ir__functions.h"
#include "robot_interfaces/msg/detail/ir__type_support.h"

#endif  // ROBOT_INTERFACES__MSG__IR_H_
