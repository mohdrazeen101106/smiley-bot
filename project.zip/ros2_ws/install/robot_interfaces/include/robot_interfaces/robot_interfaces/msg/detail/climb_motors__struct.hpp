// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/ClimbMotors.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/climb_motors.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__CLIMB_MOTORS__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__CLIMB_MOTORS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__ClimbMotors __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__ClimbMotors __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ClimbMotors_
{
  using Type = ClimbMotors_<ContainerAllocator>;

  explicit ClimbMotors_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_velocity = 0.0f;
      this->back_velocity = 0.0f;
    }
  }

  explicit ClimbMotors_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_velocity = 0.0f;
      this->back_velocity = 0.0f;
    }
  }

  // field types and members
  using _front_velocity_type =
    float;
  _front_velocity_type front_velocity;
  using _back_velocity_type =
    float;
  _back_velocity_type back_velocity;

  // setters for named parameter idiom
  Type & set__front_velocity(
    const float & _arg)
  {
    this->front_velocity = _arg;
    return *this;
  }
  Type & set__back_velocity(
    const float & _arg)
  {
    this->back_velocity = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::ClimbMotors_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::ClimbMotors_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::ClimbMotors_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::ClimbMotors_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::ClimbMotors_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::ClimbMotors_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::ClimbMotors_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::ClimbMotors_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::ClimbMotors_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::ClimbMotors_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__ClimbMotors
    std::shared_ptr<robot_interfaces::msg::ClimbMotors_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__ClimbMotors
    std::shared_ptr<robot_interfaces::msg::ClimbMotors_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ClimbMotors_ & other) const
  {
    if (this->front_velocity != other.front_velocity) {
      return false;
    }
    if (this->back_velocity != other.back_velocity) {
      return false;
    }
    return true;
  }
  bool operator!=(const ClimbMotors_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ClimbMotors_

// alias to use template instance with default allocator
using ClimbMotors =
  robot_interfaces::msg::ClimbMotors_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__CLIMB_MOTORS__STRUCT_HPP_
