// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/KfsServiceLimitSwitch.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/kfs_service_limit_switch.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__KFS_SERVICE_LIMIT_SWITCH__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__KFS_SERVICE_LIMIT_SWITCH__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/kfs_service_limit_switch__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_KfsServiceLimitSwitch_limit_switch_backs
{
public:
  explicit Init_KfsServiceLimitSwitch_limit_switch_backs(::robot_interfaces::msg::KfsServiceLimitSwitch & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::KfsServiceLimitSwitch limit_switch_backs(::robot_interfaces::msg::KfsServiceLimitSwitch::_limit_switch_backs_type arg)
  {
    msg_.limit_switch_backs = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::KfsServiceLimitSwitch msg_;
};

class Init_KfsServiceLimitSwitch_limit_switch_front
{
public:
  Init_KfsServiceLimitSwitch_limit_switch_front()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_KfsServiceLimitSwitch_limit_switch_backs limit_switch_front(::robot_interfaces::msg::KfsServiceLimitSwitch::_limit_switch_front_type arg)
  {
    msg_.limit_switch_front = std::move(arg);
    return Init_KfsServiceLimitSwitch_limit_switch_backs(msg_);
  }

private:
  ::robot_interfaces::msg::KfsServiceLimitSwitch msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::KfsServiceLimitSwitch>()
{
  return robot_interfaces::msg::builder::Init_KfsServiceLimitSwitch_limit_switch_front();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__KFS_SERVICE_LIMIT_SWITCH__BUILDER_HPP_
