// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:msg/LimitSwitch.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/limit_switch.h"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__LIMIT_SWITCH__STRUCT_H_
#define ROBOT_INTERFACES__MSG__DETAIL__LIMIT_SWITCH__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/LimitSwitch in the package robot_interfaces.
typedef struct robot_interfaces__msg__LimitSwitch
{
  int32_t ls1;
  int32_t ls2;
  int32_t ls3;
} robot_interfaces__msg__LimitSwitch;

// Struct for a sequence of robot_interfaces__msg__LimitSwitch.
typedef struct robot_interfaces__msg__LimitSwitch__Sequence
{
  robot_interfaces__msg__LimitSwitch * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__msg__LimitSwitch__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__MSG__DETAIL__LIMIT_SWITCH__STRUCT_H_
