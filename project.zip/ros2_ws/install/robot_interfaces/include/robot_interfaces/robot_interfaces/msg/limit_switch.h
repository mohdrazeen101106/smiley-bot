// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:msg/LimitSwitch.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__LIMIT_SWITCH_H_
#define ROBOT_INTERFACES__MSG__LIMIT_SWITCH_H_

#include "robot_interfaces/msg/detail/limit_switch__struct.h"
#include "robot_interfaces/msg/detail/limit_switch__functions.h"
#include "robot_interfaces/msg/detail/limit_switch__type_support.h"

#endif  // ROBOT_INTERFACES__MSG__LIMIT_SWITCH_H_
