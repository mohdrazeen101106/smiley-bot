// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/GantryVel.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/gantry_vel.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__GANTRY_VEL__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__GANTRY_VEL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/gantry_vel__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_GantryVel_gantry_vel
{
public:
  Init_GantryVel_gantry_vel()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interfaces::msg::GantryVel gantry_vel(::robot_interfaces::msg::GantryVel::_gantry_vel_type arg)
  {
    msg_.gantry_vel = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::GantryVel msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::GantryVel>()
{
  return robot_interfaces::msg::builder::Init_GantryVel_gantry_vel();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__GANTRY_VEL__BUILDER_HPP_
