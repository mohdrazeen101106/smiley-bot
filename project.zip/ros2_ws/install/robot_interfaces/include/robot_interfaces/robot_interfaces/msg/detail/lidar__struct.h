// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:msg/Lidar.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/lidar.h"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__LIDAR__STRUCT_H_
#define ROBOT_INTERFACES__MSG__DETAIL__LIDAR__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/Lidar in the package robot_interfaces.
typedef struct robot_interfaces__msg__Lidar
{
  float lidar_front;
  float lidar_back;
  float lidar_left;
  float lidar_right;
} robot_interfaces__msg__Lidar;

// Struct for a sequence of robot_interfaces__msg__Lidar.
typedef struct robot_interfaces__msg__Lidar__Sequence
{
  robot_interfaces__msg__Lidar * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__msg__Lidar__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__MSG__DETAIL__LIDAR__STRUCT_H_
