// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from robot_interfaces:msg/IR.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/ir.h"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__IR__TYPE_SUPPORT_H_
#define ROBOT_INTERFACES__MSG__DETAIL__IR__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "robot_interfaces/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_robot_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  robot_interfaces,
  msg,
  IR
)(void);

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__MSG__DETAIL__IR__TYPE_SUPPORT_H_
