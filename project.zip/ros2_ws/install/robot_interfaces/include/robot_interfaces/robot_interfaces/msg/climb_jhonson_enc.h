// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:msg/ClimbJhonsonEnc.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__CLIMB_JHONSON_ENC_H_
#define ROBOT_INTERFACES__MSG__CLIMB_JHONSON_ENC_H_

#include "robot_interfaces/msg/detail/climb_jhonson_enc__struct.h"
#include "robot_interfaces/msg/detail/climb_jhonson_enc__functions.h"
#include "robot_interfaces/msg/detail/climb_jhonson_enc__type_support.h"

#endif  // ROBOT_INTERFACES__MSG__CLIMB_JHONSON_ENC_H_
