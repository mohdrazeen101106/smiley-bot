// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/Jenc.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/jenc.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__JENC__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__JENC__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/jenc__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_Jenc_ticks
{
public:
  Init_Jenc_ticks()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interfaces::msg::Jenc ticks(::robot_interfaces::msg::Jenc::_ticks_type arg)
  {
    msg_.ticks = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::Jenc msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::Jenc>()
{
  return robot_interfaces::msg::builder::Init_Jenc_ticks();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__JENC__BUILDER_HPP_
