// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:msg/ClimbMotors.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/climb_motors.h"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__CLIMB_MOTORS__STRUCT_H_
#define ROBOT_INTERFACES__MSG__DETAIL__CLIMB_MOTORS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/ClimbMotors in the package robot_interfaces.
/**
  * Climb motor velocities (ROS -> MCU)
  * For the 2 climb wheel motors
  * To go front and back on your secondary drive 
 */
typedef struct robot_interfaces__msg__ClimbMotors
{
  float front_velocity;
  float back_velocity;
} robot_interfaces__msg__ClimbMotors;

// Struct for a sequence of robot_interfaces__msg__ClimbMotors.
typedef struct robot_interfaces__msg__ClimbMotors__Sequence
{
  robot_interfaces__msg__ClimbMotors * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__msg__ClimbMotors__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__MSG__DETAIL__CLIMB_MOTORS__STRUCT_H_
