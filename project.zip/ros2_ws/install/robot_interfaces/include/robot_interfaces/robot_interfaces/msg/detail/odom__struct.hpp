// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/Odom.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/odom.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__ODOM__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__ODOM__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__Odom __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__Odom __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Odom_
{
  using Type = Odom_<ContainerAllocator>;

  explicit Odom_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->odom_x = 0.0f;
      this->odom_y = 0.0f;
      this->current_angle = 0.0f;
    }
  }

  explicit Odom_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->odom_x = 0.0f;
      this->odom_y = 0.0f;
      this->current_angle = 0.0f;
    }
  }

  // field types and members
  using _odom_x_type =
    float;
  _odom_x_type odom_x;
  using _odom_y_type =
    float;
  _odom_y_type odom_y;
  using _current_angle_type =
    float;
  _current_angle_type current_angle;

  // setters for named parameter idiom
  Type & set__odom_x(
    const float & _arg)
  {
    this->odom_x = _arg;
    return *this;
  }
  Type & set__odom_y(
    const float & _arg)
  {
    this->odom_y = _arg;
    return *this;
  }
  Type & set__current_angle(
    const float & _arg)
  {
    this->current_angle = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::Odom_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::Odom_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::Odom_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::Odom_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::Odom_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::Odom_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::Odom_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::Odom_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::Odom_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::Odom_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__Odom
    std::shared_ptr<robot_interfaces::msg::Odom_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__Odom
    std::shared_ptr<robot_interfaces::msg::Odom_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Odom_ & other) const
  {
    if (this->odom_x != other.odom_x) {
      return false;
    }
    if (this->odom_y != other.odom_y) {
      return false;
    }
    if (this->current_angle != other.current_angle) {
      return false;
    }
    return true;
  }
  bool operator!=(const Odom_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Odom_

// alias to use template instance with default allocator
using Odom =
  robot_interfaces::msg::Odom_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__ODOM__STRUCT_HPP_
