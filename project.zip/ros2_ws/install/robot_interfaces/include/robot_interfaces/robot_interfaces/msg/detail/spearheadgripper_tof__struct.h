// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:msg/SpearheadgripperTOF.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/spearheadgripper_tof.h"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__SPEARHEADGRIPPER_TOF__STRUCT_H_
#define ROBOT_INTERFACES__MSG__DETAIL__SPEARHEADGRIPPER_TOF__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/SpearheadgripperTOF in the package robot_interfaces.
typedef struct robot_interfaces__msg__SpearheadgripperTOF
{
  float sensor1;
  float sensor2;
} robot_interfaces__msg__SpearheadgripperTOF;

// Struct for a sequence of robot_interfaces__msg__SpearheadgripperTOF.
typedef struct robot_interfaces__msg__SpearheadgripperTOF__Sequence
{
  robot_interfaces__msg__SpearheadgripperTOF * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__msg__SpearheadgripperTOF__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__MSG__DETAIL__SPEARHEADGRIPPER_TOF__STRUCT_H_
