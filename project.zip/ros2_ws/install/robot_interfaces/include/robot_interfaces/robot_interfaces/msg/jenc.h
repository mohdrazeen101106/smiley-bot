// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:msg/Jenc.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__JENC_H_
#define ROBOT_INTERFACES__MSG__JENC_H_

#include "robot_interfaces/msg/detail/jenc__struct.h"
#include "robot_interfaces/msg/detail/jenc__functions.h"
#include "robot_interfaces/msg/detail/jenc__type_support.h"

#endif  // ROBOT_INTERFACES__MSG__JENC_H_
