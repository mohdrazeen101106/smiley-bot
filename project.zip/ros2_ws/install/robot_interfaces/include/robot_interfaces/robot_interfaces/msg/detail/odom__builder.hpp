// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/Odom.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/odom.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__ODOM__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__ODOM__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/odom__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_Odom_current_angle
{
public:
  explicit Init_Odom_current_angle(::robot_interfaces::msg::Odom & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::Odom current_angle(::robot_interfaces::msg::Odom::_current_angle_type arg)
  {
    msg_.current_angle = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::Odom msg_;
};

class Init_Odom_odom_y
{
public:
  explicit Init_Odom_odom_y(::robot_interfaces::msg::Odom & msg)
  : msg_(msg)
  {}
  Init_Odom_current_angle odom_y(::robot_interfaces::msg::Odom::_odom_y_type arg)
  {
    msg_.odom_y = std::move(arg);
    return Init_Odom_current_angle(msg_);
  }

private:
  ::robot_interfaces::msg::Odom msg_;
};

class Init_Odom_odom_x
{
public:
  Init_Odom_odom_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Odom_odom_y odom_x(::robot_interfaces::msg::Odom::_odom_x_type arg)
  {
    msg_.odom_x = std::move(arg);
    return Init_Odom_odom_y(msg_);
  }

private:
  ::robot_interfaces::msg::Odom msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::Odom>()
{
  return robot_interfaces::msg::builder::Init_Odom_odom_x();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__ODOM__BUILDER_HPP_
