// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/ReedSwitch.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/reed_switch.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__REED_SWITCH__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__REED_SWITCH__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__ReedSwitch __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__ReedSwitch __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ReedSwitch_
{
  using Type = ReedSwitch_<ContainerAllocator>;

  explicit ReedSwitch_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->top = 0l;
      this->bottom = 0l;
    }
  }

  explicit ReedSwitch_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->top = 0l;
      this->bottom = 0l;
    }
  }

  // field types and members
  using _top_type =
    int32_t;
  _top_type top;
  using _bottom_type =
    int32_t;
  _bottom_type bottom;

  // setters for named parameter idiom
  Type & set__top(
    const int32_t & _arg)
  {
    this->top = _arg;
    return *this;
  }
  Type & set__bottom(
    const int32_t & _arg)
  {
    this->bottom = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::ReedSwitch_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::ReedSwitch_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::ReedSwitch_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::ReedSwitch_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::ReedSwitch_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::ReedSwitch_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::ReedSwitch_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::ReedSwitch_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::ReedSwitch_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::ReedSwitch_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__ReedSwitch
    std::shared_ptr<robot_interfaces::msg::ReedSwitch_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__ReedSwitch
    std::shared_ptr<robot_interfaces::msg::ReedSwitch_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ReedSwitch_ & other) const
  {
    if (this->top != other.top) {
      return false;
    }
    if (this->bottom != other.bottom) {
      return false;
    }
    return true;
  }
  bool operator!=(const ReedSwitch_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ReedSwitch_

// alias to use template instance with default allocator
using ReedSwitch =
  robot_interfaces::msg::ReedSwitch_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__REED_SWITCH__STRUCT_HPP_
