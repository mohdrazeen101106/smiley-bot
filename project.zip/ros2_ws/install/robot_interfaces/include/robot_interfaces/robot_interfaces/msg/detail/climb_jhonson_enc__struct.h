// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:msg/ClimbJhonsonEnc.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/climb_jhonson_enc.h"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__CLIMB_JHONSON_ENC__STRUCT_H_
#define ROBOT_INTERFACES__MSG__DETAIL__CLIMB_JHONSON_ENC__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/ClimbJhonsonEnc in the package robot_interfaces.
typedef struct robot_interfaces__msg__ClimbJhonsonEnc
{
  int32_t front_ticks;
  int32_t back_ticks;
  bool front_at_lower_limit;
  bool back_at_lower_limit;
} robot_interfaces__msg__ClimbJhonsonEnc;

// Struct for a sequence of robot_interfaces__msg__ClimbJhonsonEnc.
typedef struct robot_interfaces__msg__ClimbJhonsonEnc__Sequence
{
  robot_interfaces__msg__ClimbJhonsonEnc * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__msg__ClimbJhonsonEnc__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__MSG__DETAIL__CLIMB_JHONSON_ENC__STRUCT_H_
