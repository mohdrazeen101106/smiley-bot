// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/LimitSwitch.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/limit_switch.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__LIMIT_SWITCH__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__LIMIT_SWITCH__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__LimitSwitch __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__LimitSwitch __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct LimitSwitch_
{
  using Type = LimitSwitch_<ContainerAllocator>;

  explicit LimitSwitch_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ls1 = 0l;
      this->ls2 = 0l;
      this->ls3 = 0l;
    }
  }

  explicit LimitSwitch_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ls1 = 0l;
      this->ls2 = 0l;
      this->ls3 = 0l;
    }
  }

  // field types and members
  using _ls1_type =
    int32_t;
  _ls1_type ls1;
  using _ls2_type =
    int32_t;
  _ls2_type ls2;
  using _ls3_type =
    int32_t;
  _ls3_type ls3;

  // setters for named parameter idiom
  Type & set__ls1(
    const int32_t & _arg)
  {
    this->ls1 = _arg;
    return *this;
  }
  Type & set__ls2(
    const int32_t & _arg)
  {
    this->ls2 = _arg;
    return *this;
  }
  Type & set__ls3(
    const int32_t & _arg)
  {
    this->ls3 = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::LimitSwitch_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::LimitSwitch_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::LimitSwitch_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::LimitSwitch_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::LimitSwitch_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::LimitSwitch_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::LimitSwitch_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::LimitSwitch_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::LimitSwitch_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::LimitSwitch_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__LimitSwitch
    std::shared_ptr<robot_interfaces::msg::LimitSwitch_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__LimitSwitch
    std::shared_ptr<robot_interfaces::msg::LimitSwitch_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const LimitSwitch_ & other) const
  {
    if (this->ls1 != other.ls1) {
      return false;
    }
    if (this->ls2 != other.ls2) {
      return false;
    }
    if (this->ls3 != other.ls3) {
      return false;
    }
    return true;
  }
  bool operator!=(const LimitSwitch_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct LimitSwitch_

// alias to use template instance with default allocator
using LimitSwitch =
  robot_interfaces::msg::LimitSwitch_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__LIMIT_SWITCH__STRUCT_HPP_
