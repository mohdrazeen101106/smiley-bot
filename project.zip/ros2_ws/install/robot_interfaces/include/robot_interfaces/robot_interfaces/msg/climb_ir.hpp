// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__CLIMB_IR_HPP_
#define ROBOT_INTERFACES__MSG__CLIMB_IR_HPP_

#include "robot_interfaces/msg/detail/climb_ir__struct.hpp"
#include "robot_interfaces/msg/detail/climb_ir__builder.hpp"
#include "robot_interfaces/msg/detail/climb_ir__traits.hpp"
#include "robot_interfaces/msg/detail/climb_ir__type_support.hpp"

#endif  // ROBOT_INTERFACES__MSG__CLIMB_IR_HPP_
