// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__GANTRY_VEL_HPP_
#define ROBOT_INTERFACES__MSG__GANTRY_VEL_HPP_

#include "robot_interfaces/msg/detail/gantry_vel__struct.hpp"
#include "robot_interfaces/msg/detail/gantry_vel__builder.hpp"
#include "robot_interfaces/msg/detail/gantry_vel__traits.hpp"
#include "robot_interfaces/msg/detail/gantry_vel__type_support.hpp"

#endif  // ROBOT_INTERFACES__MSG__GANTRY_VEL_HPP_
