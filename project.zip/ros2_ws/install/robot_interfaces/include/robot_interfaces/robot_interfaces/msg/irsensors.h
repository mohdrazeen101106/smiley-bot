// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:msg/Irsensors.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__IRSENSORS_H_
#define ROBOT_INTERFACES__MSG__IRSENSORS_H_

#include "robot_interfaces/msg/detail/irsensors__struct.h"
#include "robot_interfaces/msg/detail/irsensors__functions.h"
#include "robot_interfaces/msg/detail/irsensors__type_support.h"

#endif  // ROBOT_INTERFACES__MSG__IRSENSORS_H_
