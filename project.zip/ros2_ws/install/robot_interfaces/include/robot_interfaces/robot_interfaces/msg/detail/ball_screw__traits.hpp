// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from robot_interfaces:msg/BallScrew.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/ball_screw.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__BALL_SCREW__TRAITS_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__BALL_SCREW__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "robot_interfaces/msg/detail/ball_screw__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace robot_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const BallScrew & msg,
  std::ostream & out)
{
  out << "{";
  // member: front_cmd
  {
    out << "front_cmd: ";
    rosidl_generator_traits::value_to_yaml(msg.front_cmd, out);
    out << ", ";
  }

  // member: back_cmd
  {
    out << "back_cmd: ";
    rosidl_generator_traits::value_to_yaml(msg.back_cmd, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const BallScrew & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: front_cmd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "front_cmd: ";
    rosidl_generator_traits::value_to_yaml(msg.front_cmd, out);
    out << "\n";
  }

  // member: back_cmd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "back_cmd: ";
    rosidl_generator_traits::value_to_yaml(msg.back_cmd, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const BallScrew & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace robot_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use robot_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const robot_interfaces::msg::BallScrew & msg,
  std::ostream & out, size_t indentation = 0)
{
  robot_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use robot_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const robot_interfaces::msg::BallScrew & msg)
{
  return robot_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<robot_interfaces::msg::BallScrew>()
{
  return "robot_interfaces::msg::BallScrew";
}

template<>
inline const char * name<robot_interfaces::msg::BallScrew>()
{
  return "robot_interfaces/msg/BallScrew";
}

template<>
struct has_fixed_size<robot_interfaces::msg::BallScrew>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<robot_interfaces::msg::BallScrew>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<robot_interfaces::msg::BallScrew>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ROBOT_INTERFACES__MSG__DETAIL__BALL_SCREW__TRAITS_HPP_
