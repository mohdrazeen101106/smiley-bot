// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/BallScrew.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/ball_screw.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__BALL_SCREW__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__BALL_SCREW__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/ball_screw__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_BallScrew_back_cmd
{
public:
  explicit Init_BallScrew_back_cmd(::robot_interfaces::msg::BallScrew & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::BallScrew back_cmd(::robot_interfaces::msg::BallScrew::_back_cmd_type arg)
  {
    msg_.back_cmd = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::BallScrew msg_;
};

class Init_BallScrew_front_cmd
{
public:
  Init_BallScrew_front_cmd()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BallScrew_back_cmd front_cmd(::robot_interfaces::msg::BallScrew::_front_cmd_type arg)
  {
    msg_.front_cmd = std::move(arg);
    return Init_BallScrew_back_cmd(msg_);
  }

private:
  ::robot_interfaces::msg::BallScrew msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::BallScrew>()
{
  return robot_interfaces::msg::builder::Init_BallScrew_front_cmd();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__BALL_SCREW__BUILDER_HPP_
