// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/ServoSpearhead.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/servo_spearhead.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__SERVO_SPEARHEAD__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__SERVO_SPEARHEAD__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__ServoSpearhead __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__ServoSpearhead __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ServoSpearhead_
{
  using Type = ServoSpearhead_<ContainerAllocator>;

  explicit ServoSpearhead_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->servo_finger = 0;
      this->servo_wrist = 0;
    }
  }

  explicit ServoSpearhead_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->servo_finger = 0;
      this->servo_wrist = 0;
    }
  }

  // field types and members
  using _servo_finger_type =
    int16_t;
  _servo_finger_type servo_finger;
  using _servo_wrist_type =
    int16_t;
  _servo_wrist_type servo_wrist;

  // setters for named parameter idiom
  Type & set__servo_finger(
    const int16_t & _arg)
  {
    this->servo_finger = _arg;
    return *this;
  }
  Type & set__servo_wrist(
    const int16_t & _arg)
  {
    this->servo_wrist = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::ServoSpearhead_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::ServoSpearhead_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::ServoSpearhead_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::ServoSpearhead_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::ServoSpearhead_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::ServoSpearhead_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::ServoSpearhead_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::ServoSpearhead_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::ServoSpearhead_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::ServoSpearhead_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__ServoSpearhead
    std::shared_ptr<robot_interfaces::msg::ServoSpearhead_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__ServoSpearhead
    std::shared_ptr<robot_interfaces::msg::ServoSpearhead_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ServoSpearhead_ & other) const
  {
    if (this->servo_finger != other.servo_finger) {
      return false;
    }
    if (this->servo_wrist != other.servo_wrist) {
      return false;
    }
    return true;
  }
  bool operator!=(const ServoSpearhead_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ServoSpearhead_

// alias to use template instance with default allocator
using ServoSpearhead =
  robot_interfaces::msg::ServoSpearhead_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__SERVO_SPEARHEAD__STRUCT_HPP_
