// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/Irsensors.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/irsensors.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__IRSENSORS__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__IRSENSORS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__Irsensors __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__Irsensors __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Irsensors_
{
  using Type = Irsensors_<ContainerAllocator>;

  explicit Irsensors_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ir1 = 0;
      this->ir2 = 0;
    }
  }

  explicit Irsensors_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ir1 = 0;
      this->ir2 = 0;
    }
  }

  // field types and members
  using _ir1_type =
    int16_t;
  _ir1_type ir1;
  using _ir2_type =
    int16_t;
  _ir2_type ir2;

  // setters for named parameter idiom
  Type & set__ir1(
    const int16_t & _arg)
  {
    this->ir1 = _arg;
    return *this;
  }
  Type & set__ir2(
    const int16_t & _arg)
  {
    this->ir2 = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::Irsensors_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::Irsensors_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::Irsensors_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::Irsensors_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::Irsensors_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::Irsensors_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::Irsensors_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::Irsensors_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::Irsensors_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::Irsensors_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__Irsensors
    std::shared_ptr<robot_interfaces::msg::Irsensors_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__Irsensors
    std::shared_ptr<robot_interfaces::msg::Irsensors_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Irsensors_ & other) const
  {
    if (this->ir1 != other.ir1) {
      return false;
    }
    if (this->ir2 != other.ir2) {
      return false;
    }
    return true;
  }
  bool operator!=(const Irsensors_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Irsensors_

// alias to use template instance with default allocator
using Irsensors =
  robot_interfaces::msg::Irsensors_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__IRSENSORS__STRUCT_HPP_
