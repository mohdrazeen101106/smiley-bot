// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:msg/Odom.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__ODOM_H_
#define ROBOT_INTERFACES__MSG__ODOM_H_

#include "robot_interfaces/msg/detail/odom__struct.h"
#include "robot_interfaces/msg/detail/odom__functions.h"
#include "robot_interfaces/msg/detail/odom__type_support.h"

#endif  // ROBOT_INTERFACES__MSG__ODOM_H_
