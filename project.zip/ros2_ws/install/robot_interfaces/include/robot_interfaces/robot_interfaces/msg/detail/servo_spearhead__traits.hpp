// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from robot_interfaces:msg/ServoSpearhead.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/servo_spearhead.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__SERVO_SPEARHEAD__TRAITS_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__SERVO_SPEARHEAD__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "robot_interfaces/msg/detail/servo_spearhead__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace robot_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const ServoSpearhead & msg,
  std::ostream & out)
{
  out << "{";
  // member: servo_finger
  {
    out << "servo_finger: ";
    rosidl_generator_traits::value_to_yaml(msg.servo_finger, out);
    out << ", ";
  }

  // member: servo_wrist
  {
    out << "servo_wrist: ";
    rosidl_generator_traits::value_to_yaml(msg.servo_wrist, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ServoSpearhead & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: servo_finger
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "servo_finger: ";
    rosidl_generator_traits::value_to_yaml(msg.servo_finger, out);
    out << "\n";
  }

  // member: servo_wrist
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "servo_wrist: ";
    rosidl_generator_traits::value_to_yaml(msg.servo_wrist, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ServoSpearhead & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace robot_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use robot_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const robot_interfaces::msg::ServoSpearhead & msg,
  std::ostream & out, size_t indentation = 0)
{
  robot_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use robot_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const robot_interfaces::msg::ServoSpearhead & msg)
{
  return robot_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<robot_interfaces::msg::ServoSpearhead>()
{
  return "robot_interfaces::msg::ServoSpearhead";
}

template<>
inline const char * name<robot_interfaces::msg::ServoSpearhead>()
{
  return "robot_interfaces/msg/ServoSpearhead";
}

template<>
struct has_fixed_size<robot_interfaces::msg::ServoSpearhead>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<robot_interfaces::msg::ServoSpearhead>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<robot_interfaces::msg::ServoSpearhead>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ROBOT_INTERFACES__MSG__DETAIL__SERVO_SPEARHEAD__TRAITS_HPP_
