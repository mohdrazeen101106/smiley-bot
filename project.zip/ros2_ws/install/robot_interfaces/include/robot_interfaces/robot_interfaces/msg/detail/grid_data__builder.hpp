// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/GridData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/grid_data.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__GRID_DATA__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__GRID_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/grid_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_GridData_layout
{
public:
  Init_GridData_layout()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interfaces::msg::GridData layout(::robot_interfaces::msg::GridData::_layout_type arg)
  {
    msg_.layout = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::GridData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::GridData>()
{
  return robot_interfaces::msg::builder::Init_GridData_layout();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__GRID_DATA__BUILDER_HPP_
