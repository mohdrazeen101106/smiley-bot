// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__ENCODER_HPP_
#define ROBOT_INTERFACES__MSG__ENCODER_HPP_

#include "robot_interfaces/msg/detail/encoder__struct.hpp"
#include "robot_interfaces/msg/detail/encoder__builder.hpp"
#include "robot_interfaces/msg/detail/encoder__traits.hpp"
#include "robot_interfaces/msg/detail/encoder__type_support.hpp"

#endif  // ROBOT_INTERFACES__MSG__ENCODER_HPP_
