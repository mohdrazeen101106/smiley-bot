// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/SpearheadgripperTOF.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/spearheadgripper_tof.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__SPEARHEADGRIPPER_TOF__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__SPEARHEADGRIPPER_TOF__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/spearheadgripper_tof__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_SpearheadgripperTOF_sensor2
{
public:
  explicit Init_SpearheadgripperTOF_sensor2(::robot_interfaces::msg::SpearheadgripperTOF & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::SpearheadgripperTOF sensor2(::robot_interfaces::msg::SpearheadgripperTOF::_sensor2_type arg)
  {
    msg_.sensor2 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::SpearheadgripperTOF msg_;
};

class Init_SpearheadgripperTOF_sensor1
{
public:
  Init_SpearheadgripperTOF_sensor1()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SpearheadgripperTOF_sensor2 sensor1(::robot_interfaces::msg::SpearheadgripperTOF::_sensor1_type arg)
  {
    msg_.sensor1 = std::move(arg);
    return Init_SpearheadgripperTOF_sensor2(msg_);
  }

private:
  ::robot_interfaces::msg::SpearheadgripperTOF msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::SpearheadgripperTOF>()
{
  return robot_interfaces::msg::builder::Init_SpearheadgripperTOF_sensor1();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__SPEARHEADGRIPPER_TOF__BUILDER_HPP_
