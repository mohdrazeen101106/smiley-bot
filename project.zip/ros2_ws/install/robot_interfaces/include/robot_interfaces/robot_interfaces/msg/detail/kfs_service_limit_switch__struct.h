// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:msg/KfsServiceLimitSwitch.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/kfs_service_limit_switch.h"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__KFS_SERVICE_LIMIT_SWITCH__STRUCT_H_
#define ROBOT_INTERFACES__MSG__DETAIL__KFS_SERVICE_LIMIT_SWITCH__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/KfsServiceLimitSwitch in the package robot_interfaces.
typedef struct robot_interfaces__msg__KfsServiceLimitSwitch
{
  int16_t limit_switch_front;
  int16_t limit_switch_backs;
} robot_interfaces__msg__KfsServiceLimitSwitch;

// Struct for a sequence of robot_interfaces__msg__KfsServiceLimitSwitch.
typedef struct robot_interfaces__msg__KfsServiceLimitSwitch__Sequence
{
  robot_interfaces__msg__KfsServiceLimitSwitch * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__msg__KfsServiceLimitSwitch__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__MSG__DETAIL__KFS_SERVICE_LIMIT_SWITCH__STRUCT_H_
