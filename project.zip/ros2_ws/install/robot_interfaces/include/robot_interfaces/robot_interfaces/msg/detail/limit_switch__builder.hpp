// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/LimitSwitch.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/limit_switch.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__LIMIT_SWITCH__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__LIMIT_SWITCH__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/limit_switch__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_LimitSwitch_ls3
{
public:
  explicit Init_LimitSwitch_ls3(::robot_interfaces::msg::LimitSwitch & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::LimitSwitch ls3(::robot_interfaces::msg::LimitSwitch::_ls3_type arg)
  {
    msg_.ls3 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::LimitSwitch msg_;
};

class Init_LimitSwitch_ls2
{
public:
  explicit Init_LimitSwitch_ls2(::robot_interfaces::msg::LimitSwitch & msg)
  : msg_(msg)
  {}
  Init_LimitSwitch_ls3 ls2(::robot_interfaces::msg::LimitSwitch::_ls2_type arg)
  {
    msg_.ls2 = std::move(arg);
    return Init_LimitSwitch_ls3(msg_);
  }

private:
  ::robot_interfaces::msg::LimitSwitch msg_;
};

class Init_LimitSwitch_ls1
{
public:
  Init_LimitSwitch_ls1()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LimitSwitch_ls2 ls1(::robot_interfaces::msg::LimitSwitch::_ls1_type arg)
  {
    msg_.ls1 = std::move(arg);
    return Init_LimitSwitch_ls2(msg_);
  }

private:
  ::robot_interfaces::msg::LimitSwitch msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::LimitSwitch>()
{
  return robot_interfaces::msg::builder::Init_LimitSwitch_ls1();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__LIMIT_SWITCH__BUILDER_HPP_
