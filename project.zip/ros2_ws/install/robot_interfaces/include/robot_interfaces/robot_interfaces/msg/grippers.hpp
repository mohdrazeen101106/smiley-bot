// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__GRIPPERS_HPP_
#define ROBOT_INTERFACES__MSG__GRIPPERS_HPP_

#include "robot_interfaces/msg/detail/grippers__struct.hpp"
#include "robot_interfaces/msg/detail/grippers__builder.hpp"
#include "robot_interfaces/msg/detail/grippers__traits.hpp"
#include "robot_interfaces/msg/detail/grippers__type_support.hpp"

#endif  // ROBOT_INTERFACES__MSG__GRIPPERS_HPP_
