// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/ServoSpearhead.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/servo_spearhead.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__SERVO_SPEARHEAD__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__SERVO_SPEARHEAD__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/servo_spearhead__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_ServoSpearhead_servo_wrist
{
public:
  explicit Init_ServoSpearhead_servo_wrist(::robot_interfaces::msg::ServoSpearhead & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::ServoSpearhead servo_wrist(::robot_interfaces::msg::ServoSpearhead::_servo_wrist_type arg)
  {
    msg_.servo_wrist = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::ServoSpearhead msg_;
};

class Init_ServoSpearhead_servo_finger
{
public:
  Init_ServoSpearhead_servo_finger()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ServoSpearhead_servo_wrist servo_finger(::robot_interfaces::msg::ServoSpearhead::_servo_finger_type arg)
  {
    msg_.servo_finger = std::move(arg);
    return Init_ServoSpearhead_servo_wrist(msg_);
  }

private:
  ::robot_interfaces::msg::ServoSpearhead msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::ServoSpearhead>()
{
  return robot_interfaces::msg::builder::Init_ServoSpearhead_servo_finger();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__SERVO_SPEARHEAD__BUILDER_HPP_
