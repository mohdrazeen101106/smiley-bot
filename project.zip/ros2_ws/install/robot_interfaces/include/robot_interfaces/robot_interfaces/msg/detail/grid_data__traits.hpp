// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from robot_interfaces:msg/GridData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/grid_data.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__GRID_DATA__TRAITS_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__GRID_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "robot_interfaces/msg/detail/grid_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace robot_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const GridData & msg,
  std::ostream & out)
{
  out << "{";
  // member: layout
  {
    if (msg.layout.size() == 0) {
      out << "layout: []";
    } else {
      out << "layout: [";
      size_t pending_items = msg.layout.size();
      for (auto item : msg.layout) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const GridData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: layout
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.layout.size() == 0) {
      out << "layout: []\n";
    } else {
      out << "layout:\n";
      for (auto item : msg.layout) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const GridData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace robot_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use robot_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const robot_interfaces::msg::GridData & msg,
  std::ostream & out, size_t indentation = 0)
{
  robot_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use robot_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const robot_interfaces::msg::GridData & msg)
{
  return robot_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<robot_interfaces::msg::GridData>()
{
  return "robot_interfaces::msg::GridData";
}

template<>
inline const char * name<robot_interfaces::msg::GridData>()
{
  return "robot_interfaces/msg/GridData";
}

template<>
struct has_fixed_size<robot_interfaces::msg::GridData>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<robot_interfaces::msg::GridData>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<robot_interfaces::msg::GridData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ROBOT_INTERFACES__MSG__DETAIL__GRID_DATA__TRAITS_HPP_
