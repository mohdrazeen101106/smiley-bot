// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/IR.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/ir.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__IR__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__IR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/ir__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_IR_irwall
{
public:
  explicit Init_IR_irwall(::robot_interfaces::msg::IR & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::IR irwall(::robot_interfaces::msg::IR::_irwall_type arg)
  {
    msg_.irwall = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::IR msg_;
};

class Init_IR_irbot
{
public:
  Init_IR_irbot()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_IR_irwall irbot(::robot_interfaces::msg::IR::_irbot_type arg)
  {
    msg_.irbot = std::move(arg);
    return Init_IR_irwall(msg_);
  }

private:
  ::robot_interfaces::msg::IR msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::IR>()
{
  return robot_interfaces::msg::builder::Init_IR_irbot();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__IR__BUILDER_HPP_
