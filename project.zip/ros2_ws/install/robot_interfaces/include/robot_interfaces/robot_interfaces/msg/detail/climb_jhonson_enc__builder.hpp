// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/ClimbJhonsonEnc.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/climb_jhonson_enc.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__CLIMB_JHONSON_ENC__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__CLIMB_JHONSON_ENC__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/climb_jhonson_enc__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_ClimbJhonsonEnc_back_at_lower_limit
{
public:
  explicit Init_ClimbJhonsonEnc_back_at_lower_limit(::robot_interfaces::msg::ClimbJhonsonEnc & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::ClimbJhonsonEnc back_at_lower_limit(::robot_interfaces::msg::ClimbJhonsonEnc::_back_at_lower_limit_type arg)
  {
    msg_.back_at_lower_limit = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::ClimbJhonsonEnc msg_;
};

class Init_ClimbJhonsonEnc_front_at_lower_limit
{
public:
  explicit Init_ClimbJhonsonEnc_front_at_lower_limit(::robot_interfaces::msg::ClimbJhonsonEnc & msg)
  : msg_(msg)
  {}
  Init_ClimbJhonsonEnc_back_at_lower_limit front_at_lower_limit(::robot_interfaces::msg::ClimbJhonsonEnc::_front_at_lower_limit_type arg)
  {
    msg_.front_at_lower_limit = std::move(arg);
    return Init_ClimbJhonsonEnc_back_at_lower_limit(msg_);
  }

private:
  ::robot_interfaces::msg::ClimbJhonsonEnc msg_;
};

class Init_ClimbJhonsonEnc_back_ticks
{
public:
  explicit Init_ClimbJhonsonEnc_back_ticks(::robot_interfaces::msg::ClimbJhonsonEnc & msg)
  : msg_(msg)
  {}
  Init_ClimbJhonsonEnc_front_at_lower_limit back_ticks(::robot_interfaces::msg::ClimbJhonsonEnc::_back_ticks_type arg)
  {
    msg_.back_ticks = std::move(arg);
    return Init_ClimbJhonsonEnc_front_at_lower_limit(msg_);
  }

private:
  ::robot_interfaces::msg::ClimbJhonsonEnc msg_;
};

class Init_ClimbJhonsonEnc_front_ticks
{
public:
  Init_ClimbJhonsonEnc_front_ticks()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ClimbJhonsonEnc_back_ticks front_ticks(::robot_interfaces::msg::ClimbJhonsonEnc::_front_ticks_type arg)
  {
    msg_.front_ticks = std::move(arg);
    return Init_ClimbJhonsonEnc_back_ticks(msg_);
  }

private:
  ::robot_interfaces::msg::ClimbJhonsonEnc msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::ClimbJhonsonEnc>()
{
  return robot_interfaces::msg::builder::Init_ClimbJhonsonEnc_front_ticks();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__CLIMB_JHONSON_ENC__BUILDER_HPP_
