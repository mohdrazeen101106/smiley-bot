// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/BallScrew.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/ball_screw.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__BALL_SCREW__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__BALL_SCREW__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__BallScrew __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__BallScrew __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BallScrew_
{
  using Type = BallScrew_<ContainerAllocator>;

  explicit BallScrew_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_cmd = 0;
      this->back_cmd = 0;
    }
  }

  explicit BallScrew_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_cmd = 0;
      this->back_cmd = 0;
    }
  }

  // field types and members
  using _front_cmd_type =
    int8_t;
  _front_cmd_type front_cmd;
  using _back_cmd_type =
    int8_t;
  _back_cmd_type back_cmd;

  // setters for named parameter idiom
  Type & set__front_cmd(
    const int8_t & _arg)
  {
    this->front_cmd = _arg;
    return *this;
  }
  Type & set__back_cmd(
    const int8_t & _arg)
  {
    this->back_cmd = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::BallScrew_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::BallScrew_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::BallScrew_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::BallScrew_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::BallScrew_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::BallScrew_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::BallScrew_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::BallScrew_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::BallScrew_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::BallScrew_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__BallScrew
    std::shared_ptr<robot_interfaces::msg::BallScrew_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__BallScrew
    std::shared_ptr<robot_interfaces::msg::BallScrew_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BallScrew_ & other) const
  {
    if (this->front_cmd != other.front_cmd) {
      return false;
    }
    if (this->back_cmd != other.back_cmd) {
      return false;
    }
    return true;
  }
  bool operator!=(const BallScrew_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BallScrew_

// alias to use template instance with default allocator
using BallScrew =
  robot_interfaces::msg::BallScrew_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__BALL_SCREW__STRUCT_HPP_
