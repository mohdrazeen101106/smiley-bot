// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/JmotorVelocity.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/jmotor_velocity.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__JMOTOR_VELOCITY__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__JMOTOR_VELOCITY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/jmotor_velocity__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_JmotorVelocity_j2
{
public:
  explicit Init_JmotorVelocity_j2(::robot_interfaces::msg::JmotorVelocity & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::JmotorVelocity j2(::robot_interfaces::msg::JmotorVelocity::_j2_type arg)
  {
    msg_.j2 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::JmotorVelocity msg_;
};

class Init_JmotorVelocity_j1
{
public:
  Init_JmotorVelocity_j1()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_JmotorVelocity_j2 j1(::robot_interfaces::msg::JmotorVelocity::_j1_type arg)
  {
    msg_.j1 = std::move(arg);
    return Init_JmotorVelocity_j2(msg_);
  }

private:
  ::robot_interfaces::msg::JmotorVelocity msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::JmotorVelocity>()
{
  return robot_interfaces::msg::builder::Init_JmotorVelocity_j1();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__JMOTOR_VELOCITY__BUILDER_HPP_
