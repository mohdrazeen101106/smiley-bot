// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:msg/ServoSpearhead.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__SERVO_SPEARHEAD_H_
#define ROBOT_INTERFACES__MSG__SERVO_SPEARHEAD_H_

#include "robot_interfaces/msg/detail/servo_spearhead__struct.h"
#include "robot_interfaces/msg/detail/servo_spearhead__functions.h"
#include "robot_interfaces/msg/detail/servo_spearhead__type_support.h"

#endif  // ROBOT_INTERFACES__MSG__SERVO_SPEARHEAD_H_
