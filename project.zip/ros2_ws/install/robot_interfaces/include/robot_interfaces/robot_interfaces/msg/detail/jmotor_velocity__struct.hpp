// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/JmotorVelocity.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/jmotor_velocity.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__JMOTOR_VELOCITY__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__JMOTOR_VELOCITY__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__JmotorVelocity __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__JmotorVelocity __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct JmotorVelocity_
{
  using Type = JmotorVelocity_<ContainerAllocator>;

  explicit JmotorVelocity_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->j1 = 0l;
      this->j2 = 0l;
    }
  }

  explicit JmotorVelocity_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->j1 = 0l;
      this->j2 = 0l;
    }
  }

  // field types and members
  using _j1_type =
    int32_t;
  _j1_type j1;
  using _j2_type =
    int32_t;
  _j2_type j2;

  // setters for named parameter idiom
  Type & set__j1(
    const int32_t & _arg)
  {
    this->j1 = _arg;
    return *this;
  }
  Type & set__j2(
    const int32_t & _arg)
  {
    this->j2 = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::JmotorVelocity_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::JmotorVelocity_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::JmotorVelocity_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::JmotorVelocity_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::JmotorVelocity_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::JmotorVelocity_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::JmotorVelocity_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::JmotorVelocity_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::JmotorVelocity_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::JmotorVelocity_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__JmotorVelocity
    std::shared_ptr<robot_interfaces::msg::JmotorVelocity_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__JmotorVelocity
    std::shared_ptr<robot_interfaces::msg::JmotorVelocity_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const JmotorVelocity_ & other) const
  {
    if (this->j1 != other.j1) {
      return false;
    }
    if (this->j2 != other.j2) {
      return false;
    }
    return true;
  }
  bool operator!=(const JmotorVelocity_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct JmotorVelocity_

// alias to use template instance with default allocator
using JmotorVelocity =
  robot_interfaces::msg::JmotorVelocity_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__JMOTOR_VELOCITY__STRUCT_HPP_
