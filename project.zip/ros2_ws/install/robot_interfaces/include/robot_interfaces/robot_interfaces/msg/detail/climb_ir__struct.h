// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:msg/ClimbIR.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/climb_ir.h"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__CLIMB_IR__STRUCT_H_
#define ROBOT_INTERFACES__MSG__DETAIL__CLIMB_IR__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/ClimbIR in the package robot_interfaces.
typedef struct robot_interfaces__msg__ClimbIR
{
  int16_t front_wheel;
  int16_t back_wheel;
} robot_interfaces__msg__ClimbIR;

// Struct for a sequence of robot_interfaces__msg__ClimbIR.
typedef struct robot_interfaces__msg__ClimbIR__Sequence
{
  robot_interfaces__msg__ClimbIR * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__msg__ClimbIR__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__MSG__DETAIL__CLIMB_IR__STRUCT_H_
