// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/DepthIR.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/depth_ir.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__DEPTH_IR__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__DEPTH_IR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/depth_ir__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_DepthIR_frontir
{
public:
  Init_DepthIR_frontir()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interfaces::msg::DepthIR frontir(::robot_interfaces::msg::DepthIR::_frontir_type arg)
  {
    msg_.frontir = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::DepthIR msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::DepthIR>()
{
  return robot_interfaces::msg::builder::Init_DepthIR_frontir();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__DEPTH_IR__BUILDER_HPP_
