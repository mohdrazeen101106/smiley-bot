// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:msg/ReedSwitch.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/reed_switch.h"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__REED_SWITCH__STRUCT_H_
#define ROBOT_INTERFACES__MSG__DETAIL__REED_SWITCH__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/ReedSwitch in the package robot_interfaces.
typedef struct robot_interfaces__msg__ReedSwitch
{
  int32_t top;
  int32_t bottom;
} robot_interfaces__msg__ReedSwitch;

// Struct for a sequence of robot_interfaces__msg__ReedSwitch.
typedef struct robot_interfaces__msg__ReedSwitch__Sequence
{
  robot_interfaces__msg__ReedSwitch * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__msg__ReedSwitch__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__MSG__DETAIL__REED_SWITCH__STRUCT_H_
