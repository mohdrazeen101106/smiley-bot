// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:msg/BallScrew.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__BALL_SCREW_H_
#define ROBOT_INTERFACES__MSG__BALL_SCREW_H_

#include "robot_interfaces/msg/detail/ball_screw__struct.h"
#include "robot_interfaces/msg/detail/ball_screw__functions.h"
#include "robot_interfaces/msg/detail/ball_screw__type_support.h"

#endif  // ROBOT_INTERFACES__MSG__BALL_SCREW_H_
