// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/SpearheadgripperTOF.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/spearheadgripper_tof.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__SPEARHEADGRIPPER_TOF__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__SPEARHEADGRIPPER_TOF__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__SpearheadgripperTOF __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__SpearheadgripperTOF __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SpearheadgripperTOF_
{
  using Type = SpearheadgripperTOF_<ContainerAllocator>;

  explicit SpearheadgripperTOF_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sensor1 = 0.0f;
      this->sensor2 = 0.0f;
    }
  }

  explicit SpearheadgripperTOF_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->sensor1 = 0.0f;
      this->sensor2 = 0.0f;
    }
  }

  // field types and members
  using _sensor1_type =
    float;
  _sensor1_type sensor1;
  using _sensor2_type =
    float;
  _sensor2_type sensor2;

  // setters for named parameter idiom
  Type & set__sensor1(
    const float & _arg)
  {
    this->sensor1 = _arg;
    return *this;
  }
  Type & set__sensor2(
    const float & _arg)
  {
    this->sensor2 = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::SpearheadgripperTOF_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::SpearheadgripperTOF_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::SpearheadgripperTOF_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::SpearheadgripperTOF_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::SpearheadgripperTOF_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::SpearheadgripperTOF_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::SpearheadgripperTOF_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::SpearheadgripperTOF_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::SpearheadgripperTOF_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::SpearheadgripperTOF_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__SpearheadgripperTOF
    std::shared_ptr<robot_interfaces::msg::SpearheadgripperTOF_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__SpearheadgripperTOF
    std::shared_ptr<robot_interfaces::msg::SpearheadgripperTOF_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SpearheadgripperTOF_ & other) const
  {
    if (this->sensor1 != other.sensor1) {
      return false;
    }
    if (this->sensor2 != other.sensor2) {
      return false;
    }
    return true;
  }
  bool operator!=(const SpearheadgripperTOF_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SpearheadgripperTOF_

// alias to use template instance with default allocator
using SpearheadgripperTOF =
  robot_interfaces::msg::SpearheadgripperTOF_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__SPEARHEADGRIPPER_TOF__STRUCT_HPP_
