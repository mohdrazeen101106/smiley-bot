// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:msg/JmotorVelocity.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/jmotor_velocity.h"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__JMOTOR_VELOCITY__STRUCT_H_
#define ROBOT_INTERFACES__MSG__DETAIL__JMOTOR_VELOCITY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/JmotorVelocity in the package robot_interfaces.
typedef struct robot_interfaces__msg__JmotorVelocity
{
  int32_t j1;
  int32_t j2;
} robot_interfaces__msg__JmotorVelocity;

// Struct for a sequence of robot_interfaces__msg__JmotorVelocity.
typedef struct robot_interfaces__msg__JmotorVelocity__Sequence
{
  robot_interfaces__msg__JmotorVelocity * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__msg__JmotorVelocity__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__MSG__DETAIL__JMOTOR_VELOCITY__STRUCT_H_
