// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__KFS_SERVICE_LIMIT_SWITCH_HPP_
#define ROBOT_INTERFACES__MSG__KFS_SERVICE_LIMIT_SWITCH_HPP_

#include "robot_interfaces/msg/detail/kfs_service_limit_switch__struct.hpp"
#include "robot_interfaces/msg/detail/kfs_service_limit_switch__builder.hpp"
#include "robot_interfaces/msg/detail/kfs_service_limit_switch__traits.hpp"
#include "robot_interfaces/msg/detail/kfs_service_limit_switch__type_support.hpp"

#endif  // ROBOT_INTERFACES__MSG__KFS_SERVICE_LIMIT_SWITCH_HPP_
