// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/Lidar.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/lidar.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__LIDAR__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__LIDAR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/lidar__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_Lidar_lidar_right
{
public:
  explicit Init_Lidar_lidar_right(::robot_interfaces::msg::Lidar & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::Lidar lidar_right(::robot_interfaces::msg::Lidar::_lidar_right_type arg)
  {
    msg_.lidar_right = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::Lidar msg_;
};

class Init_Lidar_lidar_left
{
public:
  explicit Init_Lidar_lidar_left(::robot_interfaces::msg::Lidar & msg)
  : msg_(msg)
  {}
  Init_Lidar_lidar_right lidar_left(::robot_interfaces::msg::Lidar::_lidar_left_type arg)
  {
    msg_.lidar_left = std::move(arg);
    return Init_Lidar_lidar_right(msg_);
  }

private:
  ::robot_interfaces::msg::Lidar msg_;
};

class Init_Lidar_lidar_back
{
public:
  explicit Init_Lidar_lidar_back(::robot_interfaces::msg::Lidar & msg)
  : msg_(msg)
  {}
  Init_Lidar_lidar_left lidar_back(::robot_interfaces::msg::Lidar::_lidar_back_type arg)
  {
    msg_.lidar_back = std::move(arg);
    return Init_Lidar_lidar_left(msg_);
  }

private:
  ::robot_interfaces::msg::Lidar msg_;
};

class Init_Lidar_lidar_front
{
public:
  Init_Lidar_lidar_front()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Lidar_lidar_back lidar_front(::robot_interfaces::msg::Lidar::_lidar_front_type arg)
  {
    msg_.lidar_front = std::move(arg);
    return Init_Lidar_lidar_back(msg_);
  }

private:
  ::robot_interfaces::msg::Lidar msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::Lidar>()
{
  return robot_interfaces::msg::builder::Init_Lidar_lidar_front();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__LIDAR__BUILDER_HPP_
