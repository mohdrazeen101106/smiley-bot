// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__VELOCITY_HPP_
#define ROBOT_INTERFACES__MSG__VELOCITY_HPP_

#include "robot_interfaces/msg/detail/velocity__struct.hpp"
#include "robot_interfaces/msg/detail/velocity__builder.hpp"
#include "robot_interfaces/msg/detail/velocity__traits.hpp"
#include "robot_interfaces/msg/detail/velocity__type_support.hpp"

#endif  // ROBOT_INTERFACES__MSG__VELOCITY_HPP_
