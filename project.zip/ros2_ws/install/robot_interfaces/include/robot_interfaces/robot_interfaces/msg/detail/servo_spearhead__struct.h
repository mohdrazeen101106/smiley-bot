// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:msg/ServoSpearhead.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/servo_spearhead.h"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__SERVO_SPEARHEAD__STRUCT_H_
#define ROBOT_INTERFACES__MSG__DETAIL__SERVO_SPEARHEAD__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/ServoSpearhead in the package robot_interfaces.
/**
  * Servo command for spearhead pickup mechanism
  * servo_finger: angle for finger/gripper servo (0-180)
  * servo_wrist: angle for wrist/rotation servo (0-180)
 */
typedef struct robot_interfaces__msg__ServoSpearhead
{
  int16_t servo_finger;
  int16_t servo_wrist;
} robot_interfaces__msg__ServoSpearhead;

// Struct for a sequence of robot_interfaces__msg__ServoSpearhead.
typedef struct robot_interfaces__msg__ServoSpearhead__Sequence
{
  robot_interfaces__msg__ServoSpearhead * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__msg__ServoSpearhead__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__MSG__DETAIL__SERVO_SPEARHEAD__STRUCT_H_
