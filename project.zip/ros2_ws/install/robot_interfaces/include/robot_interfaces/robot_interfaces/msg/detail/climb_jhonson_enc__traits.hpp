// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from robot_interfaces:msg/ClimbJhonsonEnc.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/climb_jhonson_enc.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__CLIMB_JHONSON_ENC__TRAITS_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__CLIMB_JHONSON_ENC__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "robot_interfaces/msg/detail/climb_jhonson_enc__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace robot_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const ClimbJhonsonEnc & msg,
  std::ostream & out)
{
  out << "{";
  // member: front_ticks
  {
    out << "front_ticks: ";
    rosidl_generator_traits::value_to_yaml(msg.front_ticks, out);
    out << ", ";
  }

  // member: back_ticks
  {
    out << "back_ticks: ";
    rosidl_generator_traits::value_to_yaml(msg.back_ticks, out);
    out << ", ";
  }

  // member: front_at_lower_limit
  {
    out << "front_at_lower_limit: ";
    rosidl_generator_traits::value_to_yaml(msg.front_at_lower_limit, out);
    out << ", ";
  }

  // member: back_at_lower_limit
  {
    out << "back_at_lower_limit: ";
    rosidl_generator_traits::value_to_yaml(msg.back_at_lower_limit, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ClimbJhonsonEnc & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: front_ticks
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "front_ticks: ";
    rosidl_generator_traits::value_to_yaml(msg.front_ticks, out);
    out << "\n";
  }

  // member: back_ticks
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "back_ticks: ";
    rosidl_generator_traits::value_to_yaml(msg.back_ticks, out);
    out << "\n";
  }

  // member: front_at_lower_limit
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "front_at_lower_limit: ";
    rosidl_generator_traits::value_to_yaml(msg.front_at_lower_limit, out);
    out << "\n";
  }

  // member: back_at_lower_limit
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "back_at_lower_limit: ";
    rosidl_generator_traits::value_to_yaml(msg.back_at_lower_limit, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ClimbJhonsonEnc & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace robot_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use robot_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const robot_interfaces::msg::ClimbJhonsonEnc & msg,
  std::ostream & out, size_t indentation = 0)
{
  robot_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use robot_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const robot_interfaces::msg::ClimbJhonsonEnc & msg)
{
  return robot_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<robot_interfaces::msg::ClimbJhonsonEnc>()
{
  return "robot_interfaces::msg::ClimbJhonsonEnc";
}

template<>
inline const char * name<robot_interfaces::msg::ClimbJhonsonEnc>()
{
  return "robot_interfaces/msg/ClimbJhonsonEnc";
}

template<>
struct has_fixed_size<robot_interfaces::msg::ClimbJhonsonEnc>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<robot_interfaces::msg::ClimbJhonsonEnc>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<robot_interfaces::msg::ClimbJhonsonEnc>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ROBOT_INTERFACES__MSG__DETAIL__CLIMB_JHONSON_ENC__TRAITS_HPP_
