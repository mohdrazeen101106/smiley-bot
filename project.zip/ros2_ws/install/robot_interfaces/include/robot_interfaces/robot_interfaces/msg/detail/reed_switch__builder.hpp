// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/ReedSwitch.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/reed_switch.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__REED_SWITCH__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__REED_SWITCH__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/reed_switch__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_ReedSwitch_bottom
{
public:
  explicit Init_ReedSwitch_bottom(::robot_interfaces::msg::ReedSwitch & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::ReedSwitch bottom(::robot_interfaces::msg::ReedSwitch::_bottom_type arg)
  {
    msg_.bottom = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::ReedSwitch msg_;
};

class Init_ReedSwitch_top
{
public:
  Init_ReedSwitch_top()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ReedSwitch_bottom top(::robot_interfaces::msg::ReedSwitch::_top_type arg)
  {
    msg_.top = std::move(arg);
    return Init_ReedSwitch_bottom(msg_);
  }

private:
  ::robot_interfaces::msg::ReedSwitch msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::ReedSwitch>()
{
  return robot_interfaces::msg::builder::Init_ReedSwitch_top();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__REED_SWITCH__BUILDER_HPP_
