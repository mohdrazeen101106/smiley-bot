// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:msg/DepthIR.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/depth_ir.h"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__DEPTH_IR__STRUCT_H_
#define ROBOT_INTERFACES__MSG__DETAIL__DEPTH_IR__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/DepthIR in the package robot_interfaces.
typedef struct robot_interfaces__msg__DepthIR
{
  /// for now assuming its aligned with global 90
  int16_t frontir;
} robot_interfaces__msg__DepthIR;

// Struct for a sequence of robot_interfaces__msg__DepthIR.
typedef struct robot_interfaces__msg__DepthIR__Sequence
{
  robot_interfaces__msg__DepthIR * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__msg__DepthIR__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__MSG__DETAIL__DEPTH_IR__STRUCT_H_
