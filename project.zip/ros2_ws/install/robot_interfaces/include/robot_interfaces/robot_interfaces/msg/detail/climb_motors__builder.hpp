// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/ClimbMotors.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/climb_motors.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__CLIMB_MOTORS__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__CLIMB_MOTORS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/climb_motors__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_ClimbMotors_back_velocity
{
public:
  explicit Init_ClimbMotors_back_velocity(::robot_interfaces::msg::ClimbMotors & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::ClimbMotors back_velocity(::robot_interfaces::msg::ClimbMotors::_back_velocity_type arg)
  {
    msg_.back_velocity = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::ClimbMotors msg_;
};

class Init_ClimbMotors_front_velocity
{
public:
  Init_ClimbMotors_front_velocity()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ClimbMotors_back_velocity front_velocity(::robot_interfaces::msg::ClimbMotors::_front_velocity_type arg)
  {
    msg_.front_velocity = std::move(arg);
    return Init_ClimbMotors_back_velocity(msg_);
  }

private:
  ::robot_interfaces::msg::ClimbMotors msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::ClimbMotors>()
{
  return robot_interfaces::msg::builder::Init_ClimbMotors_front_velocity();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__CLIMB_MOTORS__BUILDER_HPP_
