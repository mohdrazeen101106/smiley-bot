// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/ClimbJhonsonEnc.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/climb_jhonson_enc.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__CLIMB_JHONSON_ENC__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__CLIMB_JHONSON_ENC__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__ClimbJhonsonEnc __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__ClimbJhonsonEnc __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ClimbJhonsonEnc_
{
  using Type = ClimbJhonsonEnc_<ContainerAllocator>;

  explicit ClimbJhonsonEnc_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_ticks = 0l;
      this->back_ticks = 0l;
      this->front_at_lower_limit = false;
      this->back_at_lower_limit = false;
    }
  }

  explicit ClimbJhonsonEnc_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_ticks = 0l;
      this->back_ticks = 0l;
      this->front_at_lower_limit = false;
      this->back_at_lower_limit = false;
    }
  }

  // field types and members
  using _front_ticks_type =
    int32_t;
  _front_ticks_type front_ticks;
  using _back_ticks_type =
    int32_t;
  _back_ticks_type back_ticks;
  using _front_at_lower_limit_type =
    bool;
  _front_at_lower_limit_type front_at_lower_limit;
  using _back_at_lower_limit_type =
    bool;
  _back_at_lower_limit_type back_at_lower_limit;

  // setters for named parameter idiom
  Type & set__front_ticks(
    const int32_t & _arg)
  {
    this->front_ticks = _arg;
    return *this;
  }
  Type & set__back_ticks(
    const int32_t & _arg)
  {
    this->back_ticks = _arg;
    return *this;
  }
  Type & set__front_at_lower_limit(
    const bool & _arg)
  {
    this->front_at_lower_limit = _arg;
    return *this;
  }
  Type & set__back_at_lower_limit(
    const bool & _arg)
  {
    this->back_at_lower_limit = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::ClimbJhonsonEnc_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::ClimbJhonsonEnc_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::ClimbJhonsonEnc_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::ClimbJhonsonEnc_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::ClimbJhonsonEnc_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::ClimbJhonsonEnc_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::ClimbJhonsonEnc_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::ClimbJhonsonEnc_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::ClimbJhonsonEnc_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::ClimbJhonsonEnc_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__ClimbJhonsonEnc
    std::shared_ptr<robot_interfaces::msg::ClimbJhonsonEnc_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__ClimbJhonsonEnc
    std::shared_ptr<robot_interfaces::msg::ClimbJhonsonEnc_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ClimbJhonsonEnc_ & other) const
  {
    if (this->front_ticks != other.front_ticks) {
      return false;
    }
    if (this->back_ticks != other.back_ticks) {
      return false;
    }
    if (this->front_at_lower_limit != other.front_at_lower_limit) {
      return false;
    }
    if (this->back_at_lower_limit != other.back_at_lower_limit) {
      return false;
    }
    return true;
  }
  bool operator!=(const ClimbJhonsonEnc_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ClimbJhonsonEnc_

// alias to use template instance with default allocator
using ClimbJhonsonEnc =
  robot_interfaces::msg::ClimbJhonsonEnc_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__CLIMB_JHONSON_ENC__STRUCT_HPP_
