// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/KfsServiceLimitSwitch.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/kfs_service_limit_switch.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__KFS_SERVICE_LIMIT_SWITCH__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__KFS_SERVICE_LIMIT_SWITCH__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__KfsServiceLimitSwitch __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__KfsServiceLimitSwitch __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct KfsServiceLimitSwitch_
{
  using Type = KfsServiceLimitSwitch_<ContainerAllocator>;

  explicit KfsServiceLimitSwitch_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->limit_switch_front = 0;
      this->limit_switch_backs = 0;
    }
  }

  explicit KfsServiceLimitSwitch_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->limit_switch_front = 0;
      this->limit_switch_backs = 0;
    }
  }

  // field types and members
  using _limit_switch_front_type =
    int16_t;
  _limit_switch_front_type limit_switch_front;
  using _limit_switch_backs_type =
    int16_t;
  _limit_switch_backs_type limit_switch_backs;

  // setters for named parameter idiom
  Type & set__limit_switch_front(
    const int16_t & _arg)
  {
    this->limit_switch_front = _arg;
    return *this;
  }
  Type & set__limit_switch_backs(
    const int16_t & _arg)
  {
    this->limit_switch_backs = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::KfsServiceLimitSwitch_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::KfsServiceLimitSwitch_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::KfsServiceLimitSwitch_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::KfsServiceLimitSwitch_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::KfsServiceLimitSwitch_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::KfsServiceLimitSwitch_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::KfsServiceLimitSwitch_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::KfsServiceLimitSwitch_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::KfsServiceLimitSwitch_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::KfsServiceLimitSwitch_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__KfsServiceLimitSwitch
    std::shared_ptr<robot_interfaces::msg::KfsServiceLimitSwitch_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__KfsServiceLimitSwitch
    std::shared_ptr<robot_interfaces::msg::KfsServiceLimitSwitch_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const KfsServiceLimitSwitch_ & other) const
  {
    if (this->limit_switch_front != other.limit_switch_front) {
      return false;
    }
    if (this->limit_switch_backs != other.limit_switch_backs) {
      return false;
    }
    return true;
  }
  bool operator!=(const KfsServiceLimitSwitch_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct KfsServiceLimitSwitch_

// alias to use template instance with default allocator
using KfsServiceLimitSwitch =
  robot_interfaces::msg::KfsServiceLimitSwitch_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__KFS_SERVICE_LIMIT_SWITCH__STRUCT_HPP_
