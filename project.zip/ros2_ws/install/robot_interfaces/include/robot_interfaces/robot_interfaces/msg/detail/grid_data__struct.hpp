// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/GridData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/grid_data.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__GRID_DATA__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__GRID_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__GridData __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__GridData __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct GridData_
{
  using Type = GridData_<ContainerAllocator>;

  explicit GridData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<int32_t, 12>::iterator, int32_t>(this->layout.begin(), this->layout.end(), 0l);
    }
  }

  explicit GridData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : layout(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<int32_t, 12>::iterator, int32_t>(this->layout.begin(), this->layout.end(), 0l);
    }
  }

  // field types and members
  using _layout_type =
    std::array<int32_t, 12>;
  _layout_type layout;

  // setters for named parameter idiom
  Type & set__layout(
    const std::array<int32_t, 12> & _arg)
  {
    this->layout = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::GridData_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::GridData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::GridData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::GridData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::GridData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::GridData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::GridData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::GridData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::GridData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::GridData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__GridData
    std::shared_ptr<robot_interfaces::msg::GridData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__GridData
    std::shared_ptr<robot_interfaces::msg::GridData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GridData_ & other) const
  {
    if (this->layout != other.layout) {
      return false;
    }
    return true;
  }
  bool operator!=(const GridData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GridData_

// alias to use template instance with default allocator
using GridData =
  robot_interfaces::msg::GridData_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__GRID_DATA__STRUCT_HPP_
