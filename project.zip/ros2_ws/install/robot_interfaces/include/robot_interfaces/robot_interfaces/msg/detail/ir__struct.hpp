// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:msg/IR.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/ir.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__IR__STRUCT_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__IR__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__msg__IR __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__msg__IR __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct IR_
{
  using Type = IR_<ContainerAllocator>;

  explicit IR_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->irbot = 0;
      this->irwall = 0;
    }
  }

  explicit IR_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->irbot = 0;
      this->irwall = 0;
    }
  }

  // field types and members
  using _irbot_type =
    int16_t;
  _irbot_type irbot;
  using _irwall_type =
    int16_t;
  _irwall_type irwall;

  // setters for named parameter idiom
  Type & set__irbot(
    const int16_t & _arg)
  {
    this->irbot = _arg;
    return *this;
  }
  Type & set__irwall(
    const int16_t & _arg)
  {
    this->irwall = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::msg::IR_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::msg::IR_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::msg::IR_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::msg::IR_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::IR_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::IR_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::msg::IR_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::msg::IR_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::msg::IR_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::msg::IR_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__msg__IR
    std::shared_ptr<robot_interfaces::msg::IR_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__msg__IR
    std::shared_ptr<robot_interfaces::msg::IR_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const IR_ & other) const
  {
    if (this->irbot != other.irbot) {
      return false;
    }
    if (this->irwall != other.irwall) {
      return false;
    }
    return true;
  }
  bool operator!=(const IR_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct IR_

// alias to use template instance with default allocator
using IR =
  robot_interfaces::msg::IR_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__IR__STRUCT_HPP_
