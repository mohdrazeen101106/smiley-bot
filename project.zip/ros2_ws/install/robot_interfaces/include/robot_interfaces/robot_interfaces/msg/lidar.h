// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:msg/Lidar.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__MSG__LIDAR_H_
#define ROBOT_INTERFACES__MSG__LIDAR_H_

#include "robot_interfaces/msg/detail/lidar__struct.h"
#include "robot_interfaces/msg/detail/lidar__functions.h"
#include "robot_interfaces/msg/detail/lidar__type_support.h"

#endif  // ROBOT_INTERFACES__MSG__LIDAR_H_
