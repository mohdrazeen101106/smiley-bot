// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/Grippers.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/grippers.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__GRIPPERS__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__GRIPPERS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/grippers__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_Grippers_gripper2
{
public:
  explicit Init_Grippers_gripper2(::robot_interfaces::msg::Grippers & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::Grippers gripper2(::robot_interfaces::msg::Grippers::_gripper2_type arg)
  {
    msg_.gripper2 = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::Grippers msg_;
};

class Init_Grippers_gripper1
{
public:
  Init_Grippers_gripper1()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Grippers_gripper2 gripper1(::robot_interfaces::msg::Grippers::_gripper1_type arg)
  {
    msg_.gripper1 = std::move(arg);
    return Init_Grippers_gripper2(msg_);
  }

private:
  ::robot_interfaces::msg::Grippers msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::Grippers>()
{
  return robot_interfaces::msg::builder::Init_Grippers_gripper1();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__GRIPPERS__BUILDER_HPP_
