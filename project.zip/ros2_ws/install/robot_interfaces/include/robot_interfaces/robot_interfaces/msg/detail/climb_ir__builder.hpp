// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:msg/ClimbIR.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/msg/climb_ir.hpp"


#ifndef ROBOT_INTERFACES__MSG__DETAIL__CLIMB_IR__BUILDER_HPP_
#define ROBOT_INTERFACES__MSG__DETAIL__CLIMB_IR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/msg/detail/climb_ir__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace msg
{

namespace builder
{

class Init_ClimbIR_back_wheel
{
public:
  explicit Init_ClimbIR_back_wheel(::robot_interfaces::msg::ClimbIR & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::msg::ClimbIR back_wheel(::robot_interfaces::msg::ClimbIR::_back_wheel_type arg)
  {
    msg_.back_wheel = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::msg::ClimbIR msg_;
};

class Init_ClimbIR_front_wheel
{
public:
  Init_ClimbIR_front_wheel()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ClimbIR_back_wheel front_wheel(::robot_interfaces::msg::ClimbIR::_front_wheel_type arg)
  {
    msg_.front_wheel = std::move(arg);
    return Init_ClimbIR_back_wheel(msg_);
  }

private:
  ::robot_interfaces::msg::ClimbIR msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::msg::ClimbIR>()
{
  return robot_interfaces::msg::builder::Init_ClimbIR_front_wheel();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__MSG__DETAIL__CLIMB_IR__BUILDER_HPP_
