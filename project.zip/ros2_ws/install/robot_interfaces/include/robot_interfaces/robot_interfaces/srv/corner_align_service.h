// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:srv/CornerAlignService.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__CORNER_ALIGN_SERVICE_H_
#define ROBOT_INTERFACES__SRV__CORNER_ALIGN_SERVICE_H_

#include "robot_interfaces/srv/detail/corner_align_service__struct.h"
#include "robot_interfaces/srv/detail/corner_align_service__functions.h"
#include "robot_interfaces/srv/detail/corner_align_service__type_support.h"

#endif  // ROBOT_INTERFACES__SRV__CORNER_ALIGN_SERVICE_H_
