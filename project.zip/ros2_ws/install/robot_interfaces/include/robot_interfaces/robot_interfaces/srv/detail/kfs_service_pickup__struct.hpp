// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:srv/KfsServicePickup.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/srv/kfs_service_pickup.hpp"


#ifndef ROBOT_INTERFACES__SRV__DETAIL__KFS_SERVICE_PICKUP__STRUCT_HPP_
#define ROBOT_INTERFACES__SRV__DETAIL__KFS_SERVICE_PICKUP__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__srv__KfsServicePickup_Request __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__srv__KfsServicePickup_Request __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct KfsServicePickup_Request_
{
  using Type = KfsServicePickup_Request_<ContainerAllocator>;

  explicit KfsServicePickup_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->bot_status = 0l;
      this->pickupstate = 0l;
      this->target_height = 0l;
    }
  }

  explicit KfsServicePickup_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->bot_status = 0l;
      this->pickupstate = 0l;
      this->target_height = 0l;
    }
  }

  // field types and members
  using _bot_status_type =
    int32_t;
  _bot_status_type bot_status;
  using _pickupstate_type =
    int32_t;
  _pickupstate_type pickupstate;
  using _target_height_type =
    int32_t;
  _target_height_type target_height;

  // setters for named parameter idiom
  Type & set__bot_status(
    const int32_t & _arg)
  {
    this->bot_status = _arg;
    return *this;
  }
  Type & set__pickupstate(
    const int32_t & _arg)
  {
    this->pickupstate = _arg;
    return *this;
  }
  Type & set__target_height(
    const int32_t & _arg)
  {
    this->target_height = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__srv__KfsServicePickup_Request
    std::shared_ptr<robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__srv__KfsServicePickup_Request
    std::shared_ptr<robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const KfsServicePickup_Request_ & other) const
  {
    if (this->bot_status != other.bot_status) {
      return false;
    }
    if (this->pickupstate != other.pickupstate) {
      return false;
    }
    if (this->target_height != other.target_height) {
      return false;
    }
    return true;
  }
  bool operator!=(const KfsServicePickup_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct KfsServicePickup_Request_

// alias to use template instance with default allocator
using KfsServicePickup_Request =
  robot_interfaces::srv::KfsServicePickup_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace robot_interfaces


#ifndef _WIN32
# define DEPRECATED__robot_interfaces__srv__KfsServicePickup_Response __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__srv__KfsServicePickup_Response __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct KfsServicePickup_Response_
{
  using Type = KfsServicePickup_Response_<ContainerAllocator>;

  explicit KfsServicePickup_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->response = 0l;
    }
  }

  explicit KfsServicePickup_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->response = 0l;
    }
  }

  // field types and members
  using _response_type =
    int32_t;
  _response_type response;

  // setters for named parameter idiom
  Type & set__response(
    const int32_t & _arg)
  {
    this->response = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__srv__KfsServicePickup_Response
    std::shared_ptr<robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__srv__KfsServicePickup_Response
    std::shared_ptr<robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const KfsServicePickup_Response_ & other) const
  {
    if (this->response != other.response) {
      return false;
    }
    return true;
  }
  bool operator!=(const KfsServicePickup_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct KfsServicePickup_Response_

// alias to use template instance with default allocator
using KfsServicePickup_Response =
  robot_interfaces::srv::KfsServicePickup_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace robot_interfaces


// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__robot_interfaces__srv__KfsServicePickup_Event __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__srv__KfsServicePickup_Event __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct KfsServicePickup_Event_
{
  using Type = KfsServicePickup_Event_<ContainerAllocator>;

  explicit KfsServicePickup_Event_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : info(_init)
  {
    (void)_init;
  }

  explicit KfsServicePickup_Event_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : info(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _info_type =
    service_msgs::msg::ServiceEventInfo_<ContainerAllocator>;
  _info_type info;
  using _request_type =
    rosidl_runtime_cpp::BoundedVector<robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator>>>;
  _request_type request;
  using _response_type =
    rosidl_runtime_cpp::BoundedVector<robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator>>>;
  _response_type response;

  // setters for named parameter idiom
  Type & set__info(
    const service_msgs::msg::ServiceEventInfo_<ContainerAllocator> & _arg)
  {
    this->info = _arg;
    return *this;
  }
  Type & set__request(
    const rosidl_runtime_cpp::BoundedVector<robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<robot_interfaces::srv::KfsServicePickup_Request_<ContainerAllocator>>> & _arg)
  {
    this->request = _arg;
    return *this;
  }
  Type & set__response(
    const rosidl_runtime_cpp::BoundedVector<robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator>, 1, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<robot_interfaces::srv::KfsServicePickup_Response_<ContainerAllocator>>> & _arg)
  {
    this->response = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::srv::KfsServicePickup_Event_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::srv::KfsServicePickup_Event_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::srv::KfsServicePickup_Event_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::srv::KfsServicePickup_Event_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::srv::KfsServicePickup_Event_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::srv::KfsServicePickup_Event_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::srv::KfsServicePickup_Event_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::srv::KfsServicePickup_Event_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::srv::KfsServicePickup_Event_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::srv::KfsServicePickup_Event_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__srv__KfsServicePickup_Event
    std::shared_ptr<robot_interfaces::srv::KfsServicePickup_Event_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__srv__KfsServicePickup_Event
    std::shared_ptr<robot_interfaces::srv::KfsServicePickup_Event_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const KfsServicePickup_Event_ & other) const
  {
    if (this->info != other.info) {
      return false;
    }
    if (this->request != other.request) {
      return false;
    }
    if (this->response != other.response) {
      return false;
    }
    return true;
  }
  bool operator!=(const KfsServicePickup_Event_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct KfsServicePickup_Event_

// alias to use template instance with default allocator
using KfsServicePickup_Event =
  robot_interfaces::srv::KfsServicePickup_Event_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace robot_interfaces

namespace robot_interfaces
{

namespace srv
{

struct KfsServicePickup
{
  using Request = robot_interfaces::srv::KfsServicePickup_Request;
  using Response = robot_interfaces::srv::KfsServicePickup_Response;
  using Event = robot_interfaces::srv::KfsServicePickup_Event;
};

}  // namespace srv

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__SRV__DETAIL__KFS_SERVICE_PICKUP__STRUCT_HPP_
