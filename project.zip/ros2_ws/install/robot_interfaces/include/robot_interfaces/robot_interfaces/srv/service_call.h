// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:srv/ServiceCall.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__SERVICE_CALL_H_
#define ROBOT_INTERFACES__SRV__SERVICE_CALL_H_

#include "robot_interfaces/srv/detail/service_call__struct.h"
#include "robot_interfaces/srv/detail/service_call__functions.h"
#include "robot_interfaces/srv/detail/service_call__type_support.h"

#endif  // ROBOT_INTERFACES__SRV__SERVICE_CALL_H_
