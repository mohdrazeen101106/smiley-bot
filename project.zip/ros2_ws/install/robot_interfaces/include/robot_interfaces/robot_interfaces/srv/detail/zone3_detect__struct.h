// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:srv/Zone3Detect.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/srv/zone3_detect.h"


#ifndef ROBOT_INTERFACES__SRV__DETAIL__ZONE3_DETECT__STRUCT_H_
#define ROBOT_INTERFACES__SRV__DETAIL__ZONE3_DETECT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/Zone3Detect in the package robot_interfaces.
typedef struct robot_interfaces__srv__Zone3Detect_Request
{
  int32_t req;
} robot_interfaces__srv__Zone3Detect_Request;

// Struct for a sequence of robot_interfaces__srv__Zone3Detect_Request.
typedef struct robot_interfaces__srv__Zone3Detect_Request__Sequence
{
  robot_interfaces__srv__Zone3Detect_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__srv__Zone3Detect_Request__Sequence;

// Constants defined in the message

/// Struct defined in srv/Zone3Detect in the package robot_interfaces.
typedef struct robot_interfaces__srv__Zone3Detect_Response
{
  bool present;
} robot_interfaces__srv__Zone3Detect_Response;

// Struct for a sequence of robot_interfaces__srv__Zone3Detect_Response.
typedef struct robot_interfaces__srv__Zone3Detect_Response__Sequence
{
  robot_interfaces__srv__Zone3Detect_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__srv__Zone3Detect_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  robot_interfaces__srv__Zone3Detect_Event__request__MAX_SIZE = 1
};
// response
enum
{
  robot_interfaces__srv__Zone3Detect_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/Zone3Detect in the package robot_interfaces.
typedef struct robot_interfaces__srv__Zone3Detect_Event
{
  service_msgs__msg__ServiceEventInfo info;
  robot_interfaces__srv__Zone3Detect_Request__Sequence request;
  robot_interfaces__srv__Zone3Detect_Response__Sequence response;
} robot_interfaces__srv__Zone3Detect_Event;

// Struct for a sequence of robot_interfaces__srv__Zone3Detect_Event.
typedef struct robot_interfaces__srv__Zone3Detect_Event__Sequence
{
  robot_interfaces__srv__Zone3Detect_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__srv__Zone3Detect_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__SRV__DETAIL__ZONE3_DETECT__STRUCT_H_
