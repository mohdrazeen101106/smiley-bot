// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:srv/KfsServicePickup.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__KFS_SERVICE_PICKUP_H_
#define ROBOT_INTERFACES__SRV__KFS_SERVICE_PICKUP_H_

#include "robot_interfaces/srv/detail/kfs_service_pickup__struct.h"
#include "robot_interfaces/srv/detail/kfs_service_pickup__functions.h"
#include "robot_interfaces/srv/detail/kfs_service_pickup__type_support.h"

#endif  // ROBOT_INTERFACES__SRV__KFS_SERVICE_PICKUP_H_
