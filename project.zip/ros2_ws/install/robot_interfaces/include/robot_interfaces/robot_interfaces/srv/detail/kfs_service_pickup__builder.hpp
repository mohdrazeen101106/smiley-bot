// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:srv/KfsServicePickup.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/srv/kfs_service_pickup.hpp"


#ifndef ROBOT_INTERFACES__SRV__DETAIL__KFS_SERVICE_PICKUP__BUILDER_HPP_
#define ROBOT_INTERFACES__SRV__DETAIL__KFS_SERVICE_PICKUP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/srv/detail/kfs_service_pickup__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_KfsServicePickup_Request_target_height
{
public:
  explicit Init_KfsServicePickup_Request_target_height(::robot_interfaces::srv::KfsServicePickup_Request & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::srv::KfsServicePickup_Request target_height(::robot_interfaces::srv::KfsServicePickup_Request::_target_height_type arg)
  {
    msg_.target_height = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::KfsServicePickup_Request msg_;
};

class Init_KfsServicePickup_Request_pickupstate
{
public:
  explicit Init_KfsServicePickup_Request_pickupstate(::robot_interfaces::srv::KfsServicePickup_Request & msg)
  : msg_(msg)
  {}
  Init_KfsServicePickup_Request_target_height pickupstate(::robot_interfaces::srv::KfsServicePickup_Request::_pickupstate_type arg)
  {
    msg_.pickupstate = std::move(arg);
    return Init_KfsServicePickup_Request_target_height(msg_);
  }

private:
  ::robot_interfaces::srv::KfsServicePickup_Request msg_;
};

class Init_KfsServicePickup_Request_bot_status
{
public:
  Init_KfsServicePickup_Request_bot_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_KfsServicePickup_Request_pickupstate bot_status(::robot_interfaces::srv::KfsServicePickup_Request::_bot_status_type arg)
  {
    msg_.bot_status = std::move(arg);
    return Init_KfsServicePickup_Request_pickupstate(msg_);
  }

private:
  ::robot_interfaces::srv::KfsServicePickup_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::KfsServicePickup_Request>()
{
  return robot_interfaces::srv::builder::Init_KfsServicePickup_Request_bot_status();
}

}  // namespace robot_interfaces


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_KfsServicePickup_Response_response
{
public:
  Init_KfsServicePickup_Response_response()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interfaces::srv::KfsServicePickup_Response response(::robot_interfaces::srv::KfsServicePickup_Response::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::KfsServicePickup_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::KfsServicePickup_Response>()
{
  return robot_interfaces::srv::builder::Init_KfsServicePickup_Response_response();
}

}  // namespace robot_interfaces


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_KfsServicePickup_Event_response
{
public:
  explicit Init_KfsServicePickup_Event_response(::robot_interfaces::srv::KfsServicePickup_Event & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::srv::KfsServicePickup_Event response(::robot_interfaces::srv::KfsServicePickup_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::KfsServicePickup_Event msg_;
};

class Init_KfsServicePickup_Event_request
{
public:
  explicit Init_KfsServicePickup_Event_request(::robot_interfaces::srv::KfsServicePickup_Event & msg)
  : msg_(msg)
  {}
  Init_KfsServicePickup_Event_response request(::robot_interfaces::srv::KfsServicePickup_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_KfsServicePickup_Event_response(msg_);
  }

private:
  ::robot_interfaces::srv::KfsServicePickup_Event msg_;
};

class Init_KfsServicePickup_Event_info
{
public:
  Init_KfsServicePickup_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_KfsServicePickup_Event_request info(::robot_interfaces::srv::KfsServicePickup_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_KfsServicePickup_Event_request(msg_);
  }

private:
  ::robot_interfaces::srv::KfsServicePickup_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::KfsServicePickup_Event>()
{
  return robot_interfaces::srv::builder::Init_KfsServicePickup_Event_info();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__SRV__DETAIL__KFS_SERVICE_PICKUP__BUILDER_HPP_
