// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:srv/Zone3Detect.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__ZONE3_DETECT_H_
#define ROBOT_INTERFACES__SRV__ZONE3_DETECT_H_

#include "robot_interfaces/srv/detail/zone3_detect__struct.h"
#include "robot_interfaces/srv/detail/zone3_detect__functions.h"
#include "robot_interfaces/srv/detail/zone3_detect__type_support.h"

#endif  // ROBOT_INTERFACES__SRV__ZONE3_DETECT_H_
