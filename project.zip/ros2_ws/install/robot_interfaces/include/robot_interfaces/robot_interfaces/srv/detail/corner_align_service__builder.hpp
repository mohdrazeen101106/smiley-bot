// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:srv/CornerAlignService.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/srv/corner_align_service.hpp"


#ifndef ROBOT_INTERFACES__SRV__DETAIL__CORNER_ALIGN_SERVICE__BUILDER_HPP_
#define ROBOT_INTERFACES__SRV__DETAIL__CORNER_ALIGN_SERVICE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/srv/detail/corner_align_service__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_CornerAlignService_Request_mode
{
public:
  explicit Init_CornerAlignService_Request_mode(::robot_interfaces::srv::CornerAlignService_Request & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::srv::CornerAlignService_Request mode(::robot_interfaces::srv::CornerAlignService_Request::_mode_type arg)
  {
    msg_.mode = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::CornerAlignService_Request msg_;
};

class Init_CornerAlignService_Request_command
{
public:
  Init_CornerAlignService_Request_command()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CornerAlignService_Request_mode command(::robot_interfaces::srv::CornerAlignService_Request::_command_type arg)
  {
    msg_.command = std::move(arg);
    return Init_CornerAlignService_Request_mode(msg_);
  }

private:
  ::robot_interfaces::srv::CornerAlignService_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::CornerAlignService_Request>()
{
  return robot_interfaces::srv::builder::Init_CornerAlignService_Request_command();
}

}  // namespace robot_interfaces


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_CornerAlignService_Response_response
{
public:
  Init_CornerAlignService_Response_response()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interfaces::srv::CornerAlignService_Response response(::robot_interfaces::srv::CornerAlignService_Response::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::CornerAlignService_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::CornerAlignService_Response>()
{
  return robot_interfaces::srv::builder::Init_CornerAlignService_Response_response();
}

}  // namespace robot_interfaces


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_CornerAlignService_Event_response
{
public:
  explicit Init_CornerAlignService_Event_response(::robot_interfaces::srv::CornerAlignService_Event & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::srv::CornerAlignService_Event response(::robot_interfaces::srv::CornerAlignService_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::CornerAlignService_Event msg_;
};

class Init_CornerAlignService_Event_request
{
public:
  explicit Init_CornerAlignService_Event_request(::robot_interfaces::srv::CornerAlignService_Event & msg)
  : msg_(msg)
  {}
  Init_CornerAlignService_Event_response request(::robot_interfaces::srv::CornerAlignService_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_CornerAlignService_Event_response(msg_);
  }

private:
  ::robot_interfaces::srv::CornerAlignService_Event msg_;
};

class Init_CornerAlignService_Event_info
{
public:
  Init_CornerAlignService_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CornerAlignService_Event_request info(::robot_interfaces::srv::CornerAlignService_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_CornerAlignService_Event_request(msg_);
  }

private:
  ::robot_interfaces::srv::CornerAlignService_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::CornerAlignService_Event>()
{
  return robot_interfaces::srv::builder::Init_CornerAlignService_Event_info();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__SRV__DETAIL__CORNER_ALIGN_SERVICE__BUILDER_HPP_
