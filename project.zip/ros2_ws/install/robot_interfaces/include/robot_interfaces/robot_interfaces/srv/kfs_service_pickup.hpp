// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__KFS_SERVICE_PICKUP_HPP_
#define ROBOT_INTERFACES__SRV__KFS_SERVICE_PICKUP_HPP_

#include "robot_interfaces/srv/detail/kfs_service_pickup__struct.hpp"
#include "robot_interfaces/srv/detail/kfs_service_pickup__builder.hpp"
#include "robot_interfaces/srv/detail/kfs_service_pickup__traits.hpp"
#include "robot_interfaces/srv/detail/kfs_service_pickup__type_support.hpp"

#endif  // ROBOT_INTERFACES__SRV__KFS_SERVICE_PICKUP_HPP_
