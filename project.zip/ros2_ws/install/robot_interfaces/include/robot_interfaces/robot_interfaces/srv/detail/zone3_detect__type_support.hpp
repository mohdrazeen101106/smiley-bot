// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from robot_interfaces:srv/Zone3Detect.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__DETAIL__ZONE3_DETECT__TYPE_SUPPORT_HPP_
#define ROBOT_INTERFACES__SRV__DETAIL__ZONE3_DETECT__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "robot_interfaces/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/service_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_robot_interfaces
const rosidl_service_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  robot_interfaces,
  srv,
  Zone3Detect
)();
#ifdef __cplusplus
}
#endif

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_robot_interfaces
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  robot_interfaces,
  srv,
  Zone3Detect_Request
)();
#ifdef __cplusplus
}
#endif

// already included above
// #include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_robot_interfaces
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  robot_interfaces,
  srv,
  Zone3Detect_Response
)();
#ifdef __cplusplus
}
#endif


#endif  // ROBOT_INTERFACES__SRV__DETAIL__ZONE3_DETECT__TYPE_SUPPORT_HPP_
