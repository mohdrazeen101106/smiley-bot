// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:srv/PickSpearhead.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/srv/pick_spearhead.hpp"


#ifndef ROBOT_INTERFACES__SRV__DETAIL__PICK_SPEARHEAD__BUILDER_HPP_
#define ROBOT_INTERFACES__SRV__DETAIL__PICK_SPEARHEAD__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/srv/detail/pick_spearhead__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_PickSpearhead_Request_start
{
public:
  Init_PickSpearhead_Request_start()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interfaces::srv::PickSpearhead_Request start(::robot_interfaces::srv::PickSpearhead_Request::_start_type arg)
  {
    msg_.start = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::PickSpearhead_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::PickSpearhead_Request>()
{
  return robot_interfaces::srv::builder::Init_PickSpearhead_Request_start();
}

}  // namespace robot_interfaces


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_PickSpearhead_Response_message
{
public:
  explicit Init_PickSpearhead_Response_message(::robot_interfaces::srv::PickSpearhead_Response & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::srv::PickSpearhead_Response message(::robot_interfaces::srv::PickSpearhead_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::PickSpearhead_Response msg_;
};

class Init_PickSpearhead_Response_success
{
public:
  Init_PickSpearhead_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PickSpearhead_Response_message success(::robot_interfaces::srv::PickSpearhead_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_PickSpearhead_Response_message(msg_);
  }

private:
  ::robot_interfaces::srv::PickSpearhead_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::PickSpearhead_Response>()
{
  return robot_interfaces::srv::builder::Init_PickSpearhead_Response_success();
}

}  // namespace robot_interfaces


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_PickSpearhead_Event_response
{
public:
  explicit Init_PickSpearhead_Event_response(::robot_interfaces::srv::PickSpearhead_Event & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::srv::PickSpearhead_Event response(::robot_interfaces::srv::PickSpearhead_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::PickSpearhead_Event msg_;
};

class Init_PickSpearhead_Event_request
{
public:
  explicit Init_PickSpearhead_Event_request(::robot_interfaces::srv::PickSpearhead_Event & msg)
  : msg_(msg)
  {}
  Init_PickSpearhead_Event_response request(::robot_interfaces::srv::PickSpearhead_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_PickSpearhead_Event_response(msg_);
  }

private:
  ::robot_interfaces::srv::PickSpearhead_Event msg_;
};

class Init_PickSpearhead_Event_info
{
public:
  Init_PickSpearhead_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PickSpearhead_Event_request info(::robot_interfaces::srv::PickSpearhead_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_PickSpearhead_Event_request(msg_);
  }

private:
  ::robot_interfaces::srv::PickSpearhead_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::PickSpearhead_Event>()
{
  return robot_interfaces::srv::builder::Init_PickSpearhead_Event_info();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__SRV__DETAIL__PICK_SPEARHEAD__BUILDER_HPP_
