// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:srv/Zone3Detect.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/srv/zone3_detect.hpp"


#ifndef ROBOT_INTERFACES__SRV__DETAIL__ZONE3_DETECT__BUILDER_HPP_
#define ROBOT_INTERFACES__SRV__DETAIL__ZONE3_DETECT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/srv/detail/zone3_detect__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_Zone3Detect_Request_req
{
public:
  Init_Zone3Detect_Request_req()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interfaces::srv::Zone3Detect_Request req(::robot_interfaces::srv::Zone3Detect_Request::_req_type arg)
  {
    msg_.req = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::Zone3Detect_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::Zone3Detect_Request>()
{
  return robot_interfaces::srv::builder::Init_Zone3Detect_Request_req();
}

}  // namespace robot_interfaces


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_Zone3Detect_Response_present
{
public:
  Init_Zone3Detect_Response_present()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interfaces::srv::Zone3Detect_Response present(::robot_interfaces::srv::Zone3Detect_Response::_present_type arg)
  {
    msg_.present = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::Zone3Detect_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::Zone3Detect_Response>()
{
  return robot_interfaces::srv::builder::Init_Zone3Detect_Response_present();
}

}  // namespace robot_interfaces


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_Zone3Detect_Event_response
{
public:
  explicit Init_Zone3Detect_Event_response(::robot_interfaces::srv::Zone3Detect_Event & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::srv::Zone3Detect_Event response(::robot_interfaces::srv::Zone3Detect_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::Zone3Detect_Event msg_;
};

class Init_Zone3Detect_Event_request
{
public:
  explicit Init_Zone3Detect_Event_request(::robot_interfaces::srv::Zone3Detect_Event & msg)
  : msg_(msg)
  {}
  Init_Zone3Detect_Event_response request(::robot_interfaces::srv::Zone3Detect_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_Zone3Detect_Event_response(msg_);
  }

private:
  ::robot_interfaces::srv::Zone3Detect_Event msg_;
};

class Init_Zone3Detect_Event_info
{
public:
  Init_Zone3Detect_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Zone3Detect_Event_request info(::robot_interfaces::srv::Zone3Detect_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_Zone3Detect_Event_request(msg_);
  }

private:
  ::robot_interfaces::srv::Zone3Detect_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::Zone3Detect_Event>()
{
  return robot_interfaces::srv::builder::Init_Zone3Detect_Event_info();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__SRV__DETAIL__ZONE3_DETECT__BUILDER_HPP_
