// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:srv/ServiceCall.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "robot_interfaces/srv/service_call.hpp"


#ifndef ROBOT_INTERFACES__SRV__DETAIL__SERVICE_CALL__BUILDER_HPP_
#define ROBOT_INTERFACES__SRV__DETAIL__SERVICE_CALL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/srv/detail/service_call__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_ServiceCall_Request_climb_mode
{
public:
  explicit Init_ServiceCall_Request_climb_mode(::robot_interfaces::srv::ServiceCall_Request & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::srv::ServiceCall_Request climb_mode(::robot_interfaces::srv::ServiceCall_Request::_climb_mode_type arg)
  {
    msg_.climb_mode = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::ServiceCall_Request msg_;
};

class Init_ServiceCall_Request_bot_status
{
public:
  Init_ServiceCall_Request_bot_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ServiceCall_Request_climb_mode bot_status(::robot_interfaces::srv::ServiceCall_Request::_bot_status_type arg)
  {
    msg_.bot_status = std::move(arg);
    return Init_ServiceCall_Request_climb_mode(msg_);
  }

private:
  ::robot_interfaces::srv::ServiceCall_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::ServiceCall_Request>()
{
  return robot_interfaces::srv::builder::Init_ServiceCall_Request_bot_status();
}

}  // namespace robot_interfaces


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_ServiceCall_Response_success
{
public:
  Init_ServiceCall_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interfaces::srv::ServiceCall_Response success(::robot_interfaces::srv::ServiceCall_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::ServiceCall_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::ServiceCall_Response>()
{
  return robot_interfaces::srv::builder::Init_ServiceCall_Response_success();
}

}  // namespace robot_interfaces


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_ServiceCall_Event_response
{
public:
  explicit Init_ServiceCall_Event_response(::robot_interfaces::srv::ServiceCall_Event & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::srv::ServiceCall_Event response(::robot_interfaces::srv::ServiceCall_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::ServiceCall_Event msg_;
};

class Init_ServiceCall_Event_request
{
public:
  explicit Init_ServiceCall_Event_request(::robot_interfaces::srv::ServiceCall_Event & msg)
  : msg_(msg)
  {}
  Init_ServiceCall_Event_response request(::robot_interfaces::srv::ServiceCall_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_ServiceCall_Event_response(msg_);
  }

private:
  ::robot_interfaces::srv::ServiceCall_Event msg_;
};

class Init_ServiceCall_Event_info
{
public:
  Init_ServiceCall_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ServiceCall_Event_request info(::robot_interfaces::srv::ServiceCall_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_ServiceCall_Event_request(msg_);
  }

private:
  ::robot_interfaces::srv::ServiceCall_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::ServiceCall_Event>()
{
  return robot_interfaces::srv::builder::Init_ServiceCall_Event_info();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__SRV__DETAIL__SERVICE_CALL__BUILDER_HPP_
